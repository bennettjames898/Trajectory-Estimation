"""
curvefit_predictor.py
=====================
Trajectory prediction using ONLY curve fitting of the recorded time history.
No Kalman filter, no motion/dynamics model, no particle filter: just
least-squares polynomials fitted to the most recent data and extrapolated.

    python curvefit_predictor.py                          # built-in demo
    python curvefit_predictor.py --csv track.csv --horizon 60
    python curvefit_predictor.py --csv track.csv --model kinematic --window 15
    python curvefit_predictor.py --csv track.csv --truth what_happened.csv

Input CSV (same format as predict_from_history.py)
--------------------------------------------------
    t, x, y, z   [s, m]   local ENU frame: x = East, y = North, z = Up
Extra columns (vx, ax, ...) are ignored - only positions are fitted.
Irregular time steps are resampled to the median step.

Two kinds of curve fit
----------------------
 1. CARTESIAN: fit x(t), y(t), z(t) separately with a polynomial of order
    1, 2 or 3 over the last W seconds and evaluate it ahead in time.
    (MATLAB: p = polyfit(t - t_end, x, n); polyval(p, lead))
    Order 1 = constant velocity, order 2 = constant acceleration.
    Weak point: a turn becomes a parabola, which drifts outside the arc.

 2. KINEMATIC (speed / heading): from the positions in the window, get the
    velocity with a local quadratic fit (Savitzky-Golay), convert it to
    horizontal speed, heading and vertical speed, fit a polynomial to EACH
    of those time histories, extrapolate them and integrate to position.
    Heading order 1 = constant turn rate, so a turn extrapolates as an ARC.
    Still pure curve fitting - just in a better set of variables.

Optional "fading memory" weights w = exp((t - t_end) / tau), tau = W/3,
count recent points more (MATLAB: lscov(A, y, w)).

Optional DAMPED TRENDS (Gardner & McKenzie, 1985, "Forecasting trends in
time series", Management Science 31(10)): whatever the polynomial says
is CHANGING - turn rate, speed change, vertical speed, (Cartesian)
acceleration - is faded out with a time constant T in {10, 20, 40, 80} s
instead of being extrapolated for ever.  A turn in progress then
continues for roughly T seconds and rolls out, a climb levels off.  The
backtest picks T, i.e. it learns how long this object's maneuvers tend to
last.  Plain (undamped) polynomials are always among the candidates.

How the fit is chosen: BACKTESTING
----------------------------------
The history is replayed: at ~60 earlier cut-off times the script pretends
the data stopped there, makes a prediction with every candidate
(model x window x order x weighting x damping), and compares it with what was
actually measured afterwards.  The candidate with the smallest RMS
position error over all lead times up to the horizon is used.
--select combine instead blends the best few fits at each lead time with
weights 1 / MSE (Bates & Granger, 1969, "The combination of forecasts",
Operational Research Quarterly 20(4)).  Averaging positions of fits that
disagree (still turning vs rolled out) can give a path that no fit
predicts, so the single best fit is the default.

The same backtest errors give the UNCERTAINTY: for each lead time the
errors are resolved into along-track / cross-track (horizontal) and
vertical, and their spread gives the 50% / 95% ellipses and altitude
bands.  These are empirical - they say "this is how wrong this fit has
been on this object's own history at this lead time".  If the horizon
is longer than the history allows backtesting, the error growth is
extrapolated with a power law (flagged in the output).

Limitations (by design - this is the curve-fit-only baseline)
--------------------------------------------------------------
  * A fit only knows what the window shows.  A maneuver that starts after
    the last data point is invisible; one that is in progress is
    extrapolated for ever (a turn keeps turning) unless a damped trend is
    chosen, and then it fades at the rate typical of the history.
  * No physics: nothing stops the fit predicting impossible speeds or g.
  * Backtest errors are only representative if the future behaves like
    the history (same maneuver style).  Cut-offs overlap, so the 95%
    level rests on fewer independent samples than it looks.
  * Errors are measured against the noisy positions, so the bands include
    the measurement noise (the error never goes below the noise level).

Needs: numpy, scipy, matplotlib.
"""

import argparse

import numpy as np
from scipy.signal import savgol_filter
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
from matplotlib.lines import Line2D

# ---------------------------------------------------------------------------
# 1. Loading
# ---------------------------------------------------------------------------
ALIASES = {
    "t": ["t", "time", "time_s", "t_s", "sec", "seconds"],
    "x": ["x", "e", "east", "pos_x", "px", "x_m", "east_m"],
    "y": ["y", "n", "north", "pos_y", "py", "y_m", "north_m"],
    "z": ["z", "u", "up", "alt", "altitude", "h", "pos_z", "pz", "z_m", "alt_m"],
}


def load_history(path):
    """Read t, x, y, z from a CSV with a header row.  Returns t (N,), P (N,3)."""
    raw = np.genfromtxt(path, delimiter=",", names=True, dtype=float,
                        case_sensitive="lower", deletechars="")
    cols = {c.strip(): raw[c] for c in raw.dtype.names}
    out = {}
    for key, names in ALIASES.items():
        hit = next((n for n in names if n in cols), None)
        if hit is None:
            raise ValueError(f"{path}: no column for '{key}'. Columns found: {list(cols)}")
        out[key] = np.asarray(cols[hit], float)
    t = out["t"]
    P = np.column_stack([out["x"], out["y"], out["z"]])
    good = np.isfinite(t) & np.all(np.isfinite(P), axis=1)
    order = np.argsort(t[good])
    return t[good][order], P[good][order]


def make_uniform(t, P):
    """Resample to a uniform time step (the median recorded step)."""
    dt = float(np.median(np.diff(t)))
    if np.max(np.abs(np.diff(t) - dt)) < 1e-3 * dt:
        return t, P, dt
    tu = np.arange(t[0], t[-1] + 0.5 * dt, dt)
    print(f"  note: irregular time steps - resampled to dt = {dt:.3f} s")
    Pu = np.column_stack([np.interp(tu, t, P[:, k]) for k in range(3)])
    return tu, Pu, dt


def noise_level(P):
    """Per-axis position noise (1-sigma) from second differences, robust to
    outliers (median absolute deviation).  For white noise the second
    difference has variance 6 sigma^2; real motion adds little at typical
    sample rates."""
    d2 = P[2:] - 2 * P[1:-1] + P[:-2]
    mad = 1.4826 * np.median(np.abs(d2 - np.median(d2, axis=0)), axis=0)
    return mad / np.sqrt(6.0)


# ---------------------------------------------------------------------------
# 2. Curve fits
# ---------------------------------------------------------------------------
def fit_poly(u, Y, order, tau=None):
    """Weighted least-squares polynomial fit.

    u   : (n,) time, scaled and relative to the cut-off (so u <= 0)
    Y   : (n,) or (n, m) values to fit (each column fitted separately)
    tau : fading-memory time constant in the same units as u (None = equal weights)
    Returns C (order+1, m), lowest power first:  y(u) = C[0] + C[1] u + C[2] u^2 ...
    (Like MATLAB polyfit, but with weights and the powers in the other order.)
    """
    Y = np.asarray(Y, float).reshape(len(u), -1)
    w = np.ones_like(u) if tau is None else np.exp(u / tau)
    A = np.vander(u, order + 1, increasing=True)
    sw = np.sqrt(w)[:, None]
    C, *_ = np.linalg.lstsq(A * sw, Y * sw, rcond=None)
    return C


def eval_poly(C, u):
    """Evaluate fit_poly coefficients at u.  Returns (len(u), m)."""
    return np.vander(np.atleast_1d(u), C.shape[0], increasing=True) @ C


def deriv_poly(C):
    """Coefficients of dy/du for fit_poly coefficients C."""
    if C.shape[0] == 1:
        return np.zeros_like(C)
    return C[1:] * np.arange(1, C.shape[0])[:, None]


def cumtrapz0(y, h):
    """Cumulative trapezoidal integral starting at 0 (MATLAB cumtrapz * h)."""
    return np.concatenate([np.zeros((1,) + y.shape[1:]),
                           np.cumsum(0.5 * (y[1:] + y[:-1]) * h, axis=0)], axis=0)


def predict_cartesian(s, Pw, leads, order, tau, damp=None):
    """Polynomial in time for each of x, y, z.
    s: times relative to the cut-off (last = 0), Pw: positions in the window.
    damp: time constant [s] with which the velocity CHANGE predicted by the
    polynomial fades out (None = plain polynomial extrapolation)."""
    W = -s[0]                                   # scale time by the window length
    C = fit_poly(s / W, Pw, order, None if tau is None else tau / W)
    if damp is None or order < 2:
        return eval_poly(C, leads / W)
    step = min(leads[0], 0.5)
    tf = np.arange(0.0, leads[-1] + 0.5 * step, step)
    v = eval_poly(deriv_poly(C), tf / W) / W                    # fitted velocity
    v = v[0] + (v - v[0]) * np.exp(-tf / damp)[:, None]          # damped trend
    pos = eval_poly(C, 0.0)[0] + cumtrapz0(v, step)
    return np.column_stack([np.interp(leads, tf, pos[:, k]) for k in range(3)])


def predict_kinematic(s, Pw, leads, order, tau, dt, damp=None, sg_seconds=6.0):
    """Polynomials for heading, horizontal speed and vertical speed, then
    integrate.  order = (heading order, speed order).
    damp: time constant [s] with which the fitted turn rate, speed change and
    vertical speed fade out, so the extrapolation tends to straight, level,
    constant-speed flight (None = plain polynomial extrapolation)."""
    o_psi, o_spd = order
    W = -s[0]
    u = s / W
    tw = None if tau is None else tau / W
    n = len(s)

    # velocity history from the positions INSIDE the window only (so the
    # backtest never peeks past the cut-off): local quadratic (Savitzky-Golay)
    wl = min(int(round(sg_seconds / dt)) | 1, n if n % 2 else n - 1)
    wl = max(wl, 5)
    V = savgol_filter(Pw, wl, 2, deriv=1, delta=dt, axis=0, mode="interp")
    vh = np.hypot(V[:, 0], V[:, 1])
    psi = np.unwrap(np.arctan2(V[:, 0], V[:, 1]))       # heading from North [rad]

    C_psi = fit_poly(u, psi, o_psi, tw)
    C_spd = fit_poly(u, np.column_stack([vh, V[:, 2]]), o_spd, tw)
    # where it is now: smoothed position at the cut-off (quadratic or cubic fit)
    p0 = eval_poly(fit_poly(u, Pw, min(max(2, o_psi + 1), 3), tw), 0.0)[0]

    # extrapolate heading / speed / vertical speed, optionally damped:
    #   q(L) = q(0) + integral_0^L q'(l) exp(-l / damp) dl   (heading, speed)
    #   vz(L) = vz_fit(L) exp(-L / damp)                      (climb levels off)
    step = min(dt, 0.5)
    tf = np.arange(0.0, leads[-1] + 0.5 * step, step)
    g = np.ones_like(tf) if damp is None else np.exp(-tf / damp)
    psi_f = eval_poly(C_psi, 0.0)[0, 0] + cumtrapz0(eval_poly(deriv_poly(C_psi), tf / W)[:, 0]
                                                    / W * g, step)
    vh_f = eval_poly(C_spd, 0.0)[0, 0] + cumtrapz0(eval_poly(deriv_poly(C_spd), tf / W)[:, 0]
                                                   / W * g, step)
    vz_f = eval_poly(C_spd, tf / W)[:, 1] * g
    vh_f = np.maximum(vh_f, 1.0)                        # speed can't go negative
    vel = np.column_stack([vh_f * np.sin(psi_f), vh_f * np.cos(psi_f), vz_f])
    pos = p0 + cumtrapz0(vel, step)
    return np.column_stack([np.interp(leads, tf, pos[:, k]) for k in range(3)])


def predict(cand, s, Pw, leads, dt):
    if cand["model"] == "cartesian":
        return predict_cartesian(s, Pw, leads, cand["order"], cand["tau"], cand["damp"])
    return predict_kinematic(s, Pw, leads, cand["order"], cand["tau"], dt, cand["damp"])


def label(c, short=False):
    fade = (", fading" if c["tau"] is not None else "") + \
        (f", trend damped T={c['damp']:g} s" if c["damp"] is not None else "")
    if c["model"] == "cartesian":
        name = f"Cartesian poly{c['order']}"
    else:
        name = f"Speed/heading (hdg poly{c['order'][0]}, spd poly{c['order'][1]})"
    return name if short else f"{name}, {c['W']:g} s window{fade}"


DAMPS = (None, 10.0, 20.0, 40.0, 80.0)


def make_candidates(T_hist, dt, models, window=None, order=None, fading=True, damping=True):
    windows = [window] if window else [w for w in (4, 8, 15, 30, 60, 90)
                                       if w <= 0.35 * T_hist and w / dt >= 4]
    if not windows:
        raise ValueError("history too short for any fit window")
    taus = (None, "W/3") if fading else (None,)
    damps = DAMPS if damping else (None,)
    cands = []
    for W in windows:
        for tau in taus:
            tv = None if tau is None else W / 3.0
            if "cartesian" in models:
                for p in (1, 2, 3):
                    if (order is None or order == str(p)) and W / dt + 1 >= p + 3:
                        for d in (damps if p >= 2 else (None,)):     # nothing to damp in a line
                            cands.append(dict(model="cartesian", W=W, order=p, tau=tv, damp=d))
            if "kinematic" in models:
                for o in ((0, 0), (1, 0), (1, 1), (2, 1)):
                    if order is None or order == f"{o[0]},{o[1]}":
                        for d in damps:              # (0,0) still has a vertical speed to damp
                            cands.append(dict(model="kinematic", W=W, order=o, tau=tv, damp=d))
    if not cands:
        raise ValueError("no candidate fits match --model/--window/--order")
    return cands


# ---------------------------------------------------------------------------
# 3. Backtest: replay the history, score every candidate
# ---------------------------------------------------------------------------
def backtest(t, P, dt, cands, H, n_cuts=60):
    nH = int(round(H / dt))
    leads = np.arange(1, nH + 1) * dt
    nW_max = int(round(max(c["W"] for c in cands) / dt))
    k_first, k_last = nW_max, len(t) - 1 - nH
    cuts = np.unique(np.linspace(k_first, k_last, min(n_cuts, k_last - k_first + 1))
                     .round().astype(int))
    results = []
    for c in cands:
        nW = int(round(c["W"] / dt))
        E = np.empty((len(cuts), nH, 3))
        PR = np.empty_like(E)
        for i, k in enumerate(cuts):
            s = t[k - nW:k + 1] - t[k]
            PR[i] = predict(c, s, P[k - nW:k + 1], leads, dt)
            E[i] = P[k + 1:k + nH + 1] - PR[i]          # actual - predicted
        rms = np.sqrt(np.mean(np.sum(E ** 2, axis=2), axis=0))
        results.append(dict(cand=c, E=E, PR=PR, P0=P[cuts], rms=rms,
                            score=float(np.sqrt(np.mean(rms ** 2)))))
    results.sort(key=lambda r: r["score"])
    return results, leads, cuts


def combine(results, dt, K=5, smooth_s=5.0):
    """Lead-time-dependent combination of the candidate fits.

    The best fit depends on the lead time (a constant-turn-rate fit usually
    wins at short leads, a straight line once the turn is likely to have
    ended).  At every lead the K candidates with the smallest backtest RMS
    error get weights proportional to 1 / MSE (Bates & Granger, 1969,
    "The combination of forecasts"); the weights are then smoothed over
    ~smooth_s seconds of lead time so the path doesn't jump.
    Because the errors are linear in the predictions, the combined forecast's
    backtest errors are the same weighted sum of the candidates' errors.
    (Weights and errors come from the same backtest, so the combined error is
    slightly optimistic.)"""
    R = np.array([r["rms"] for r in results])                    # (n_cand, n_lead)
    n_c, nH = R.shape
    Wt = np.zeros((nH, n_c))
    for j in range(nH):
        top = np.argsort(R[:, j])[:K]
        Wt[j, top] = 1.0 / R[top, j] ** 2
    Wt /= Wt.sum(axis=1, keepdims=True)
    m = max(1, int(round(smooth_s / dt)))
    kern = np.ones(m) / m
    pad = np.vstack([np.repeat(Wt[:1], m, 0), Wt, np.repeat(Wt[-1:], m, 0)])
    Wt = np.column_stack([np.convolve(pad[:, c], kern, mode="same")[m:-m] for c in range(n_c)])
    Wt /= Wt.sum(axis=1, keepdims=True)
    used = np.flatnonzero(Wt.max(axis=0) > 1e-3)
    Wt = Wt[:, used] / Wt[:, used].sum(axis=1, keepdims=True)
    members = [results[c] for c in used]
    E = np.einsum("jc,cijk->ijk", Wt, np.array([r["E"] for r in members]))
    PR = np.einsum("jc,cijk->ijk", Wt, np.array([r["PR"] for r in members]))
    rms = np.sqrt(np.mean(np.sum(E ** 2, axis=2), axis=0))
    return dict(E=E, PR=PR, P0=members[0]["P0"], rms=rms, score=float(np.sqrt(np.mean(rms ** 2))),
                members=members, weights=Wt, W=max(r["cand"]["W"] for r in members),
                name=f"combination of {len(members)} curve fits (weights vary with lead time)")


def single(r):
    """Wrap one candidate in the same form as combine()'s output."""
    return dict(r, members=[r], weights=np.ones((len(r["rms"]), 1)), W=r["cand"]["W"],
                name=label(r["cand"]))


def predict_chosen(ch, t, P, dt, leads):
    """Forecast from the last data point with a single fit or a combination
    (weights beyond the backtested leads = those at the last backtested lead)."""
    nb = ch["weights"].shape[0]
    Wl = ch["weights"][np.minimum(np.arange(len(leads)), nb - 1)]
    path = np.zeros((len(leads), 3))
    for c, r in enumerate(ch["members"]):
        nW = int(round(r["cand"]["W"] / dt))
        path += Wl[:, c:c + 1] * predict(r["cand"], t[-nW - 1:] - t[-1], P[-nW - 1:], leads, dt)
    return path, Wl


def track_axes(path, start):
    """Unit along-track and cross-track (left) horizontal vectors along a
    predicted path (n_leads, 3) that starts from position `start`."""
    prev = np.vstack([start, path[:-1]])
    d = path[:, :2] - prev[:, :2]
    u = d / np.maximum(np.linalg.norm(d, axis=1, keepdims=True), 1e-9)
    return u, np.column_stack([-u[:, 1], u[:, 0]])


def error_stats(r):
    """Per-lead statistics of the backtest errors of one candidate:
    horizontal second-moment matrix E[e e^T] in along/cross-track axes
    (about ZERO, so any systematic bias widens the region rather than
    shifting it - ~60 overlapping cut-offs are too few to trust a bias
    correction), the Mahalanobis radii that hold 50% / 95% of the errors,
    and vertical error quantiles."""
    E, PR, P0 = r["E"], r["PR"], r["P0"]
    n_cut, nH, _ = E.shape
    AC = np.empty((n_cut, nH, 2))
    for i in range(n_cut):
        u, nrm = track_axes(PR[i], P0[i])
        AC[i, :, 0] = np.sum(E[i, :, :2] * u, axis=1)
        AC[i, :, 1] = np.sum(E[i, :, :2] * nrm, axis=1)
    st = dict(C=np.empty((nH, 2, 2)), k=np.empty((nH, 2)), zq=np.empty((nH, 5)))
    for j in range(nH):
        X = AC[:, j]
        C = X.T @ X / len(X) + 1e-6 * np.eye(2)
        d2 = np.einsum("ni,ij,nj->n", X, np.linalg.inv(C), X)
        st["C"][j] = C
        st["k"][j] = np.sqrt(np.quantile(d2, [0.5, 0.95]))
        st["zq"][j] = np.quantile(E[:, j, 2], [0.025, 0.25, 0.5, 0.75, 0.975])
    return st


def extend_stats(st, leads_bt, leads):
    """Stats for every forecast lead.  Beyond the backtested range the error
    is scaled by (lead / last backtested lead)^a, with a fitted to how the
    RMS error grew over the second half of the backtested leads."""
    nb = len(leads_bt)
    if len(leads) <= nb:
        return {k: v[:len(leads)] for k, v in st.items()}, np.zeros(len(leads), bool), None
    size = np.sqrt(np.trace(st["C"], axis1=1, axis2=2))
    half = slice(nb // 2, nb)
    a = float(np.clip(np.polyfit(np.log(leads_bt[half]), np.log(size[half]), 1)[0], 0.5, 3.0))
    f = (leads[nb:] / leads_bt[-1]) ** a
    out = {
        "C": np.concatenate([st["C"], st["C"][-1] * (f ** 2)[:, None, None]]),
        "k": np.vstack([st["k"], np.repeat(st["k"][-1:], len(f), axis=0)]),
        "zq": np.vstack([st["zq"], st["zq"][-1] * f[:, None]]),
    }
    extrap = np.r_[np.zeros(nb, bool), np.ones(len(f), bool)]
    return out, extrap, a


def ellipse_at(st, j, path, start, level):
    """Centre (E, N), semi-axes and angle [deg] of the error ellipse at lead j."""
    u, nrm = track_axes(path, start)
    R = np.column_stack([u[j], nrm[j]])                 # along/cross -> East/North
    centre = path[j, :2]
    C = R @ st["C"][j] @ R.T
    lam, vec = np.linalg.eigh(C)
    kk = st["k"][j][0 if level == 0.5 else 1]
    ang = np.degrees(np.arctan2(vec[1, 1], vec[0, 1]))
    return centre, kk * np.sqrt(lam[1]), kk * np.sqrt(lam[0]), ang


# ---------------------------------------------------------------------------
# 4. Plot
# ---------------------------------------------------------------------------
def plot_results(t, P, dt, res, out_png, truth=None):
    ch, leads, path, st, extrap = res["chosen"], res["leads"], res["path"], res["st"], res["extrap"]
    W = ch["W"]
    fig = plt.figure(figsize=(15, 9.5))
    gs = fig.add_gridspec(2, 2, width_ratios=[1.7, 1.0], height_ratios=[1.0, 1.25],
                          wspace=0.22, hspace=0.32)
    ax = fig.add_subplot(gs[:, 0])
    axz = fig.add_subplot(gs[0, 1])
    axe = fig.add_subplot(gs[1, 1])
    km = 1e-3

    # --- map
    in_win = t >= t[-1] - W
    ax.plot(P[:, 0] * km, P[:, 1] * km, ".", color="#b0b0b0", ms=2.5)
    ax.plot(P[in_win, 0] * km, P[in_win, 1] * km, ".", color="#333333", ms=4)
    ax.plot(P[-1, 0] * km, P[-1, 1] * km, "o", color="k", ms=8)
    full = np.vstack([P[-1], path])
    ax.plot(full[~np.r_[False, extrap], 0] * km, full[~np.r_[False, extrap], 1] * km,
            color="#1f6fd1", lw=2.2)
    if extrap.any():
        k0 = np.argmax(extrap)
        ax.plot(path[k0 - 1:, 0] * km, path[k0 - 1:, 1] * km, color="#1f6fd1", lw=2.2, ls="--")
    marks = sorted({int(round(f * len(leads))) - 1 for f in (0.25, 0.5, 0.75, 1.0)})
    for j in marks:
        for level, ls in ((0.95, "-"), (0.5, "--")):
            c, a, b, ang = ellipse_at(st, j, path, P[-1], level)
            ax.add_patch(Ellipse(c * km, 2 * a * km, 2 * b * km, angle=ang, fill=False,
                                 ec="#1f6fd1", ls=ls, lw=1.3))
        ax.plot(*path[j, :2] * km, "o", color="#1f6fd1", ms=5)
        ax.annotate(f"+{leads[j]:.0f} s", path[j, :2] * km, xytext=(6, 6),
                    textcoords="offset points", fontsize=9, color="#1f6fd1")
    if truth is not None:
        tt = truth[:, 0] - t[-1]
        fut = (tt >= 0) & (tt <= leads[-1] + 1e-6)
        ax.plot(truth[fut, 1] * km, truth[fut, 2] * km, color="#c0392b", ls=":", lw=1.8)
        for j in marks:
            tr = [np.interp(leads[j], tt, truth[:, c]) for c in (1, 2)]
            ax.plot(tr[0] * km, tr[1] * km, "X", color="#c0392b", mec="k", ms=9)
    handles = [Line2D([], [], marker=".", color="#b0b0b0", ls="", label="measured history"),
               Line2D([], [], marker=".", color="#333333", ls="",
                      label=f"last {W:g} s (used by the fit)"),
               Line2D([], [], marker="o", color="k", ls="", label="last data point"),
               Line2D([], [], color="#1f6fd1", lw=2.2, label="curve-fit prediction"),
               Line2D([], [], color="#1f6fd1", ls="--", lw=1.3, label="50% region (backtest)"),
               Line2D([], [], color="#1f6fd1", ls="-", lw=1.3, label="95% region (backtest)")]
    if extrap.any():
        handles.append(Line2D([], [], color="#1f6fd1", ls="--", lw=2.2,
                              label=f"beyond +{leads[~extrap][-1]:.0f} s: error growth extrapolated"))
    if truth is not None:
        handles.append(Line2D([], [], color="#c0392b", ls=":", marker="X", mec="k",
                              label="actual path / positions"))
    ax.legend(handles=handles, fontsize=8, loc="best", framealpha=0.9)
    ax.set_aspect("equal", adjustable="datalim")
    ax.set_xlabel("East [km]")
    ax.set_ylabel("North [km]")
    ax.grid(alpha=0.3)
    ax.set_title(f"Curve-fit prediction, {leads[-1]:.0f} s ahead\n{ch['name']}",
                 fontsize=11)

    # --- altitude vs time
    th = t - t[-1]
    zq = st["zq"]
    zc = path[:, 2]
    tf = np.r_[0.0, leads]
    band = lambda q: np.r_[P[-1, 2], zc + zq[:, q]] * km
    axz.plot(th, P[:, 2] * km, ".", color="#9a9a9a", ms=2.5)
    axz.fill_between(tf, band(0), band(4), color="#1f6fd1", alpha=0.18, label="95%")
    axz.fill_between(tf, band(1), band(3), color="#1f6fd1", alpha=0.35, label="50%")
    axz.plot(tf, np.r_[P[-1, 2], zc] * km, color="#1f6fd1", lw=2, label="prediction")
    if truth is not None:
        axz.plot(truth[:, 0] - t[-1], truth[:, 3] * km, color="#c0392b", ls=":", lw=1.6,
                 label="actual")
    axz.axvline(0, color="k", lw=0.8)
    axz.set_xlim(max(th[0], -4 * leads[-1]), leads[-1] * 1.03)
    vis = th >= axz.get_xlim()[0]
    yl = np.r_[P[vis, 2], band(0) / km, band(4) / km] * km
    axz.set_ylim(yl.min() - 0.1 * np.ptp(yl) - 0.05, yl.max() + 0.1 * np.ptp(yl) + 0.05)
    axz.set_xlabel("time relative to last data point [s]")
    axz.set_ylabel("altitude [km]")
    axz.set_title("Altitude", fontsize=10)
    axz.grid(alpha=0.3)
    axz.legend(fontsize=7, loc="best")

    # --- backtest error vs lead, best of each fit family
    fams = {}
    for r in res["results"]:
        key = label(r["cand"], short=True)
        if key not in fams:
            fams[key] = r
    lb = res["leads_bt"]
    for key, r in fams.items():
        axe.plot(lb, r["rms"], lw=1.1, ls="-" if r["cand"]["model"] == "kinematic" else "--",
                 label=key.replace("Speed/heading", "Spd/hdg"))
    axe.plot(lb, ch["rms"], lw=2.8, color="#1f6fd1", zorder=5,
             label="USED (" + ("combination" if len(ch["members"]) > 1 else "see title") + ")")
    axe.axhline(np.linalg.norm(res["sigma"]), color="k", lw=0.8, ls=":",
                label="measurement noise level")
    axe.set_xlabel("lead time [s]")
    axe.set_ylabel("RMS 3-D position error [m]")
    axe.set_yscale("log")
    axe.set_title(f"Backtest on the history ({len(res['cuts'])} cut-off times)\n"
                  "best window/weighting/damping per fit type (dashed = Cartesian)",
                  fontsize=10)
    axe.grid(alpha=0.3, which="both")
    axe.legend(fontsize=7, loc="upper center", bbox_to_anchor=(0.5, -0.17), ncol=2,
               frameon=False)

    fig.savefig(out_png, dpi=140, bbox_inches="tight")
    plt.close(fig)


# ---------------------------------------------------------------------------
# 5. Demo data
# ---------------------------------------------------------------------------
def make_demo(hist_path, truth_path, t_hist=240.0, t_future=150.0, dt=0.5, noise=15.0, seed=1):
    """Maneuvering aircraft at ~230 m/s: turns, climbs, speed changes.  The
    history ends 25 s into a 2.5 deg/s right turn; 10 s after the history
    ends it rolls out and starts a gentle climb."""
    #          t0    t1   turn rate [deg/s]  vertical speed [m/s]  accel [m/s^2]
    segs = [(0, 30, 0.0, 0.0, 0.0), (30, 55, -3.0, 0.0, 0.0), (55, 90, 0.0, 15.0, 0.0),
            (90, 120, 4.0, 15.0, 0.0), (120, 150, 0.0, 0.0, 1.0), (150, 185, -2.0, -10.0, 0.0),
            (185, 215, 0.0, 0.0, -0.5), (215, 250, 2.5, 0.0, 0.0), (250, 1e9, 0.0, 8.0, 0.0)]
    h = 0.05
    x = np.array([0.0, 0.0, 6000.0])
    V, psi = 230.0, np.radians(90.0)
    rows = []
    for i in range(int(round((t_hist + t_future) / h)) + 1):
        tt = i * h
        if i % int(round(dt / h)) == 0:
            rows.append([tt, *x])
        _, _, r, vz, a = next(s for s in segs if s[0] <= tt < s[1])
        psi += np.radians(r) * h
        V += a * h
        x = x + h * np.array([V * np.sin(psi), V * np.cos(psi), vz])
    T = np.array(rows)
    hist = T[:, 0] <= t_hist + 1e-9
    H = T[hist].copy()
    H[:, 1:] += np.random.default_rng(seed).normal(0.0, noise, (hist.sum(), 3))
    np.savetxt(hist_path, H, delimiter=",", fmt="%.3f", header="t,x,y,z", comments="")
    np.savetxt(truth_path, T[~hist], delimiter=",", fmt="%.3f", header="t,x,y,z", comments="")


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1],
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--csv", help="history CSV (t,x,y,z); omit for the built-in demo")
    ap.add_argument("--horizon", type=float, default=60.0, help="seconds ahead [60]")
    ap.add_argument("--model", choices=("auto", "cartesian", "kinematic"), default="auto",
                    help="which kind of curve fit to consider [auto = both]")
    ap.add_argument("--window", type=float, help="force the fit window [s]")
    ap.add_argument("--order", help="force the order: '2' (Cartesian) or '1,0' "
                                    "(kinematic heading,speed)")
    ap.add_argument("--select", choices=("single", "combine"), default="single",
                    help="use the single best fit, or combine the best fits with "
                         "lead-dependent weights [single]")
    ap.add_argument("--no-fading", action="store_true", help="equal weights only")
    ap.add_argument("--no-damping", action="store_true",
                    help="plain polynomial extrapolation only (no damped trends)")
    ap.add_argument("--cuts", type=int, default=60, help="backtest cut-off times [60]")
    ap.add_argument("--truth", help="optional CSV (t,x,y,z) of what actually happened")
    ap.add_argument("--out", default="curvefit_prediction", help="output file prefix")
    args = ap.parse_args()

    if args.csv is None:
        args.csv, args.truth = "demo_cf_history.csv", "demo_cf_truth.csv"
        make_demo(args.csv, args.truth)
        print(f"No --csv given: wrote demo data to {args.csv} (+ {args.truth})")

    print(f"\nLoading {args.csv}")
    t, P, dt = make_uniform(*load_history(args.csv))
    T_hist = t[-1] - t[0]
    sigma = noise_level(P)
    print(f"  {len(t)} samples, {T_hist:.0f} s at dt = {dt:.3f} s; position noise ~ "
          f"{', '.join(f'{s:.1f}' for s in sigma)} m (E, N, U)")

    models = ("cartesian", "kinematic") if args.model == "auto" else (args.model,)
    cands = make_candidates(T_hist, dt, models, args.window, args.order, not args.no_fading,
                            not args.no_damping)

    # how far ahead the history lets us backtest (need >= 30 s of cut-offs)
    W_max = max(c["W"] for c in cands)
    H_bt = min(args.horizon, T_hist - W_max - 30.0)
    while H_bt < min(args.horizon, 10.0) and args.window is None:
        cands = [c for c in cands if c["W"] < W_max]
        if not cands:
            raise SystemExit("ERROR: history too short to backtest")
        W_max = max(c["W"] for c in cands)
        H_bt = min(args.horizon, T_hist - W_max - 30.0)
    if H_bt <= 2 * dt:
        raise SystemExit("ERROR: history too short to backtest - give more data")
    H_bt = dt * int(H_bt / dt)
    print(f"\nBacktesting {len(cands)} candidate fits, leads up to {H_bt:.0f} s ...")
    results, leads_bt, cuts = backtest(t, P, dt, cands, H_bt, args.cuts)
    # forecasts from cut-offs closer together than the lead time overlap, so
    # at the longest lead there are only about (span / lead + 1) independent ones
    n_indep = (t[cuts[-1]] - t[cuts[0]]) / H_bt + 1.0
    if n_indep < 5:
        print(f"  NOTE: at the longest lead ({H_bt:.0f} s) the backtest rests on only ~"
              f"{n_indep:.1f} independent samples - treat the long-lead fit choice and "
              "bands as rough (more history or a shorter horizon helps)")
    best = results[0]
    chosen = single(best) if args.select == "single" else combine(results, dt)

    print("\nBest candidates (RMS 3-D error over leads 0..{:.0f} s; at the last lead):".format(H_bt))
    for r in results[:8]:
        print(f"  {r['score']:8.0f} m   {r['rms'][-1]:8.0f} m   {label(r['cand'])}")

    if len(chosen["members"]) > 1:
        print(f"\nCombined forecast: RMS {chosen['score']:.0f} m over all leads, "
              f"{chosen['rms'][-1]:.0f} m at the last lead.  Weights:")
        js = sorted({int(round(f * len(leads_bt))) - 1 for f in (0.1, 0.25, 0.5, 1.0)})
        print("  " + "".join(f"{'+%.0f s' % leads_bt[j]:>9}" for j in js) + "   fit")
        for c, r in enumerate(chosen["members"]):
            print("  " + "".join(f"{100 * chosen['weights'][j, c]:8.0f}%" for j in js)
                  + "   " + label(r["cand"]))

    # final prediction from the last data point
    leads = np.arange(1, int(round(args.horizon / dt)) + 1) * dt
    path, _ = predict_chosen(chosen, t, P, dt, leads)
    st, extrap, a = extend_stats(error_stats(chosen), leads_bt, leads)
    if a is not None:
        print(f"\n  NOTE: horizon {args.horizon:.0f} s > backtested {H_bt:.0f} s - uncertainty "
              f"beyond that is extrapolated (error ~ lead^{a:.2f})")

    res = dict(chosen=chosen, results=results, leads=leads, leads_bt=leads_bt, cuts=cuts,
               path=path, st=st, extrap=extrap, sigma=sigma)
    truth = np.genfromtxt(args.truth, delimiter=",", skip_header=1) if args.truth else None
    png = f"{args.out}.png"
    plot_results(t, P, dt, res, png, truth)

    # --- report and CSV
    rows = []
    print(f"\nPrediction ({chosen['name']}):")
    for j in range(len(leads)):
        c95, a95, b95, ang = ellipse_at(st, j, path, P[-1], 0.95)
        rows.append([leads[j], t[-1] + leads[j], *path[j], a95, b95, ang,
                     path[j, 2] + st["zq"][j, 0], path[j, 2] + st["zq"][j, 4], extrap[j]])
    show = sorted({int(round(f * len(leads))) - 1 for f in (0.25, 0.5, 0.75, 1.0)})
    for j in show:
        r = rows[j]
        msg = (f"  +{r[0]:4.0f} s: E {r[2] / 1e3:7.2f} km, N {r[3] / 1e3:7.2f} km, "
               f"alt {r[4] / 1e3:5.2f} km | 95% ellipse {r[5]:.0f} x {r[6]:.0f} m"
               + (" (extrapolated)" if r[10] else ""))
        if truth is not None:
            tt = truth[:, 0] - t[-1]
            tr = np.array([np.interp(leads[j], tt, truth[:, c]) for c in (1, 2, 3)])
            c95 = ellipse_at(st, j, path, P[-1], 0.95)[0]
            d = tr[:2] - c95
            th = np.radians(r[7])
            dm = np.array([d @ [np.cos(th), np.sin(th)], d @ [-np.sin(th), np.cos(th)]])
            inside = (dm[0] / r[5]) ** 2 + (dm[1] / r[6]) ** 2 <= 1
            msg += (f" | actual: {np.linalg.norm(tr[:2] - path[j, :2]):.0f} m off horiz, "
                    f"{tr[2] - path[j, 2]:+.0f} m vert, inside 95%: {inside}")
        print(msg)

    csv_out = f"{args.out}.csv"
    np.savetxt(csv_out, np.array(rows, float), delimiter=",",
               fmt=["%.2f", "%.2f", "%.1f", "%.1f", "%.1f", "%.1f", "%.1f", "%.1f",
                    "%.1f", "%.1f", "%d"],
               header="lead_s,t_s,east_m,north_m,up_m,ell95_semimajor_m,ell95_semiminor_m,"
                      "ell95_angle_deg_from_east,up_lo95_m,up_hi95_m,extrapolated",
               comments="")
    print(f"\nSaved: {png}, {csv_out}")


if __name__ == "__main__":
    main()
