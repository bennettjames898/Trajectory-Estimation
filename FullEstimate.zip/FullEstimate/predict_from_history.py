"""
predict_from_history.py
=======================
Long-horizon trajectory prediction from a recorded time history of
position, velocity and acceleration.  Output: a plot of the cloud of
possible positions at a chosen time horizon (plus the cloud as CSV).

    python predict_from_history.py                       # built-in demo
    python predict_from_history.py --csv track.csv --horizon 180
    python predict_from_history.py --csv track.csv --horizon 240 \
        --dest A 70000 50000 6000 --dest B 90000 -40000 4000
    python predict_from_history.py --csv track.csv --obstacles obstacles.json

Input CSV (header row, comma separated, local ENU frame, SI units)
-----------------------------------------------------------------
    t, x, y, z, vx, vy, vz, ax, ay, az
    t [s]; x = East, y = North, z = Up [m]; v [m/s]; a [m/s^2]
    a = kinematic acceleration (d v / dt), gravity NOT included.
Common aliases are accepted (time, east, north, up/alt, ve/vn/vu, ...).
Velocity and/or acceleration columns may be missing - they are then
derived from position by smoothed differentiation.  Irregular time steps
are resampled to a uniform step.

What the script does
--------------------
 1. SMOOTH + NOISE LEVEL: a Savitzky-Golay fit (local cubic) smooths each
    channel; the residual scatter gives the noise level of the data, and
    the filter coefficients give the uncertainty of the smoothed values.
 2. LEARN FROM THE HISTORY (nothing about the object is assumed known):
      * demonstrated envelope - load factor, level-turn bank, speed range,
        and (load factor, excess acceleration) pairs - taken at a 2-sigma
        lower bound and held for >= 2 s, so noise can't inflate it.  These
        become LOWER bounds on each particle's capability;
      * maneuver level - RMS lateral acceleration while maneuvering, which
        sets how hard the 'evasive' hypothesis jinks;
      * climbs and descents - segments where the vertical speed stays
        clearly non-zero.  If the history ENDS in one, the forecast continues
        it at the current rate for a random remaining time, then levels off;
        new climbs/descents are started at the rate seen in the history, with
        sizes and rates resampled from it.  No climbs/descents in the
        history -> altitude is held.  The demonstrated climb rate is also a
        lower bound on climb capability (--no-vertical turns this off).
 3. INTENT INFERENCE: particles are started `--window` seconds before the
    end of the data and a particle filter assimilates the positions since
    then, so intents (straight / continue turn / evasive / fly to a
    destination) and capability classes that don't explain the recent
    track lose weight.
 4. PREDICT: every particle is flown forward with a 3-DOF point-mass model
    under its own intent, capability and (unknown) wind.  Intents can switch
    during the forecast.  The spread of the particles is the forecast.
 5. OBSTACLES: any forecast trajectory that enters an obstacle region is
    thrown out (weight 0), so the cloud only holds trajectories that stay
    clear.  By default everything below 0 m altitude is an obstacle
    (--floor ALT / --floor none).  More regions come from a JSON file
    (--obstacles), e.g.
        [{"type": "floor",    "alt": 0},
         {"type": "cylinder", "name": "SAM site", "center": [-45000, -30000],
                              "radius": 6000, "z_max": 12000},
         {"type": "polygon",  "name": "ridge", "z_max": 3800,
                              "vertices": [[-62000, -2000], [-56000, -3000],
                                           [-51000, 26000], [-57000, 27000]]},
         {"type": "box",      "min": [E, N, U], "max": [E, N, U]},
         {"type": "ceiling",  "alt": 15000},
         {"type": "terrain",  "file": "terrain.npz"}]   (arrays e, n, elev)
    See obstacles.py for details.  Climb/descent TARGETS are kept
    --alt-margin (150 m) clear of floors/ceilings, as a pilot would; the
    plot and report show how much probability was thrown out.  Note: a
    real object would usually climb or turn to avoid an obstacle, which
    this model does not simulate - it only removes trajectories that hit.

Needs: numpy, scipy, matplotlib, and intent_mc.py + obstacles.py in the same folder.

Methods and references
----------------------
Numbers in [] refer to the list at the end of this header.  The particle
filter, point-mass model, intent switching, Liu-West parameter learning,
ensemble-Kalman correction and highest-density regions are described, with
references, in the header of intent_mc.py.  This file adds:

Smoothing and differentiation.  Each channel is smoothed - and velocity /
acceleration derived when missing - with Savitzky-Golay filters: a cubic
least-squares polynomial fitted in a sliding window, which is equivalent to
a fixed FIR filter [1, 2].  Derivatives use 2x and 3x wider windows because
differentiating amplifies noise.

Noise levels.  Each channel's noise standard deviation is estimated from
the smoothing residuals with the median absolute deviation, scaled by
1.4826 so that it equals the standard deviation for Gaussian noise while
ignoring outliers [3, 4].  Residuals are smaller than the noise because the
fit absorbs part of it, so the estimate is divided by sqrt(1 - leverage)
[5].  The uncertainty of a SMOOTHED value is the per-sample noise times the
root-sum-square of the filter coefficients, ||c|| (the variance of a
weighted sum of independent errors) [2].
  KNOWN ISSUE: the code uses the window-average leverage (p + 1) / w; the
  residual at the window centre actually has leverage c0, the centre filter
  coefficient.  For the default 3 s window at 2 Hz (w = 7, p = 3; c0 = 0.33
  vs 0.57) the noise is over-estimated by about 24%; with (1 - c0) the
  estimate is unbiased (checked on simulated white noise).

Demonstrated envelope (lower bounds on capability).  From the smoothed
acceleration: load factor n = |a + g z_hat| / g, level-turn bank
atan(a_lateral / g), and excess acceleration a_x = a . v_hat + g sin(gamma),
which is the specific excess power P_s divided by speed [6, 7].  Each value
is taken at a 2-sigma one-sided lower confidence bound and must be held for
2 s (rolling minimum) before it counts.  (Load factor, excess acceleration)
pairs form a partial energy-maneuverability diagram [7]; with the
point-mass drag model each pair implies a_thrust >= a_x + k (n^2 - 1).  The
2-sigma / 2 s rule is an engineering choice.

Manoeuvre level.  RMS lateral acceleration while clearly manoeuvring, with
the measurement variance subtracted and recent data weighted more
(exponential forgetting, 120 s).  It plays the role of the manoeuvre
variance in Singer-type models [8, 9] and sets how hard the 'evasive'
hypothesis turns.

Climb / descent behaviour.
  * Segments: runs where |vertical speed| > max(2 sigma, 2 m/s) for at
    least 4 s; same-direction runs separated by < 4 s are merged.  The
    segment's rate is the 90th percentile of |vz| (the steady rate, not
    the level-off).  These thresholds are engineering choices.
  * A climb/descent still going at the end of the history is continued at
    the current rate for a random time
        T ~ Exponential(mean = max(typical segment duration, time so far)).
    Scaling by the time elapsed so far is in the spirit of Gott's "delta-t"
    argument - with nothing else to go on, something that has lasted t is
    likely to last a comparable time again [10].  It is a heuristic: Gott's
    rule gives a median remaining time of t, this exponential gives 0.69 t
    with a long tail.
  * New altitude changes occur at rate n_segments / (T_history + T0): the
    posterior-mean rate of a Poisson process under a Gamma prior worth
    T0 = 60 s of "no change" [11].  Their direction is a climb with
    probability (n_climbs + 1) / (n_segments + 2), Laplace's rule of
    succession [11, 12]; sizes and rates are resampled from the history.
  * Guidance: constant vertical speed, then altitude capture with the
    proportional altitude-hold loop - the vertical-speed / altitude-capture
    pattern of a basic autopilot [13].

Obstacles.  Trajectories that enter an obstacle are discarded (weight set
to zero), i.e. the forecast is conditioned on "never entered an obstacle".
This is the acceptance/rejection approach to constrained particle filtering
[14]; [15] surveys the alternatives.  The geometry tests are in
obstacles.py.

Plots and validation.  The 50% / 95% regions are highest-density regions
[16]; altitude bands use weighted quantiles with the inverted-CDF
definition (Hyndman & Fan type 1) [17].  The checks reported during
development - how often the truth falls inside the 95% region - follow the
calibration-and-sharpness view of probabilistic forecasting [18].

References
  [1] Savitzky, A., Golay, M. J. E. (1964). Smoothing and differentiation of
      data by simplified least squares procedures. Analytical Chemistry,
      36(8), 1627-1639.
  [2] Schafer, R. W. (2011). What is a Savitzky-Golay filter? IEEE Signal
      Processing Magazine, 28(4), 111-117.
  [3] Hampel, F. R. (1974). The influence curve and its role in robust
      estimation. Journal of the American Statistical Association, 69(346),
      383-393.
  [4] Rousseeuw, P. J., Croux, C. (1993). Alternatives to the median
      absolute deviation. Journal of the American Statistical Association,
      88(424), 1273-1283.
  [5] Hastie, T. J., Tibshirani, R. J. (1990). Generalized Additive Models.
      Chapman & Hall.  (Leverage and degrees of freedom of linear
      smoothers.)
  [6] Rutowski, E. S. (1954). Energy approach to the general aircraft
      performance problem. Journal of the Aeronautical Sciences, 21(3),
      187-195.
  [7] Boyd, J. R., Christie, T. P., Gibson, J. E. (1966).
      Energy-Maneuverability. Report APGC-TR-66-4, Air Proving Ground
      Center, Eglin AFB, FL.
  [8] Singer, R. A. (1970). Estimating optimal tracking filter performance
      for manned maneuvering targets. IEEE Transactions on Aerospace and
      Electronic Systems, AES-6(4), 473-483.
  [9] Li, X. R., Jilkov, V. P. (2003). Survey of maneuvering target
      tracking. Part I: Dynamic models. IEEE Transactions on Aerospace and
      Electronic Systems, 39(4), 1333-1364.
  [10] Gott, J. R. (1993). Implications of the Copernican principle for our
      future prospects. Nature, 363(6427), 315-319.
  [11] Gelman, A., Carlin, J. B., Stern, H. S., Dunson, D. B., Vehtari, A.,
      Rubin, D. B. (2013). Bayesian Data Analysis, 3rd ed. CRC Press.
  [12] Jaynes, E. T. (2003). Probability Theory: The Logic of Science.
      Cambridge University Press.
  [13] Stevens, B. L., Lewis, F. L., Johnson, E. N. (2016). Aircraft Control
      and Simulation, 3rd ed. Wiley.
  [14] Shao, X., Huang, B., Lee, J. M. (2010). Constrained Bayesian state
      estimation - A comparative study and a new particle filter based
      approach. Journal of Process Control, 20(2), 143-157.
  [15] Simon, D. (2010). Kalman filtering with state constraints: a survey
      of linear and nonlinear algorithms. IET Control Theory &
      Applications, 4(8), 1303-1318.
  [16] Hyndman, R. J. (1996). Computing and graphing highest density
      regions. The American Statistician, 50(2), 120-126.
  [17] Hyndman, R. J., Fan, Y. (1996). Sample quantiles in statistical
      packages. The American Statistician, 50(4), 361-365.
  [18] Gneiting, T., Balabdaoui, F., Raftery, A. E. (2007). Probabilistic
      forecasts, calibration and sharpness. Journal of the Royal
      Statistical Society: Series B, 69(2), 243-268.
"""

import argparse
import copy
import json

import numpy as np
from scipy.signal import savgol_coeffs, savgol_filter
from scipy.ndimage import maximum_filter1d, minimum_filter1d
from scipy.special import logsumexp
from scipy.stats import gaussian_kde, norm
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

from intent_mc import (G, AircraftPerformance, Forecast, Intent, IntentMonteCarlo,
                       default_classes, point_mass_step, wrap_pi)
from obstacles import Floor, inside_any, load_obstacles

ZHAT = np.array([0.0, 0.0, 1.0])

# ---------------------------------------------------------------------------
# 1. Loading
# ---------------------------------------------------------------------------
ALIASES = {
    "t": ["t", "time", "time_s", "t_s", "sec", "seconds"],
    "x": ["x", "e", "east", "pos_x", "px", "x_m", "east_m"],
    "y": ["y", "n", "north", "pos_y", "py", "y_m", "north_m"],
    "z": ["z", "u", "up", "alt", "altitude", "h", "pos_z", "pz", "z_m", "alt_m"],
    "vx": ["vx", "ve", "v_e", "vel_x", "xdot", "v_east", "vx_mps"],
    "vy": ["vy", "vn", "v_n", "vel_y", "ydot", "v_north", "vy_mps"],
    "vz": ["vz", "vu", "v_u", "vel_z", "zdot", "v_up", "hdot", "vz_mps"],
    "ax": ["ax", "ae", "a_e", "acc_x", "xddot", "a_east", "ax_mps2"],
    "ay": ["ay", "an", "a_n", "acc_y", "yddot", "a_north", "ay_mps2"],
    "az": ["az", "au", "a_u", "acc_z", "zddot", "a_up", "az_mps2"],
}


def load_history(path):
    """Read the CSV into a dict of 1-D arrays keyed t, x, y, z, vx, ... (the
    velocity/acceleration keys are absent if the file doesn't have them)."""
    raw = np.genfromtxt(path, delimiter=",", names=True, dtype=float,
                        case_sensitive="lower", deletechars="")
    cols = {c.strip(): raw[c] for c in raw.dtype.names}
    out = {}
    for key, names in ALIASES.items():
        hit = next((n for n in names if n in cols), None)
        if hit is not None:
            out[key] = np.asarray(cols[hit], float)
    missing = [k for k in ("t", "x", "y", "z") if k not in out]
    if missing:
        raise ValueError(f"{path}: could not find column(s) {missing}. "
                         f"Columns found: {list(cols)}. Expected names like {ALIASES['t'][:2]}, "
                         f"{ALIASES['x'][:3]}, ...")
    for grp in (("vx", "vy", "vz"), ("ax", "ay", "az")):
        have = [k in out for k in grp]
        if any(have) and not all(have):                     # partial vector: ignore it
            print(f"  note: only some of {grp} found - deriving that vector from position")
            for k in grp:
                out.pop(k, None)
    good = np.all(np.isfinite(np.column_stack(list(out.values()))), axis=1)
    order = np.argsort(out["t"][good])
    return {k: v[good][order] for k, v in out.items()}


def make_uniform(d):
    """Resample onto a uniform time step (median of the recorded steps)."""
    t = d["t"]
    dts = np.diff(t)
    dt = float(np.median(dts))
    if np.max(np.abs(dts - dt)) < 1e-3 * dt:
        return d, dt
    tu = np.arange(t[0], t[-1] + 0.5 * dt, dt)
    print(f"  note: irregular time steps - resampled to dt = {dt:.3f} s")
    return {k: (tu if k == "t" else np.interp(tu, t, v)) for k, v in d.items()}, dt


# ---------------------------------------------------------------------------
# 2. Smoothing and noise levels
# ---------------------------------------------------------------------------
def _robust_sigma(res, window, poly):
    """Noise std from Savitzky-Golay residuals (median absolute deviation,
    corrected for the part of the noise the fit itself absorbs)."""
    s = 1.4826 * np.median(np.abs(res - np.median(res, axis=0)), axis=0)
    return float(np.sqrt(np.mean(s ** 2) / max(1.0 - (poly + 1) / window, 0.2)))


def smooth_history(d, dt, smooth_s=3.0, poly=3):
    """Smooth position/velocity/acceleration and estimate noise levels.

    Returns dict with p, v, a (N,3) smoothed; z (N,3) raw positions;
    sig_raw_p (noise of a single raw position sample, per axis) and
    sig_p, sig_v, sig_a (1-sigma of the SMOOTHED values, per axis);
    plus which vectors were derived rather than measured."""
    w = int(round(smooth_s / dt)) | 1                       # odd number of samples
    w = max(w, poly + 2 + (poly % 2 == 0))
    n = len(d["t"])
    if n < w + 2:
        raise ValueError(f"only {n} samples - need more than {w + 2} for smoothing")
    # Differentiating noisy data amplifies the noise, so derived velocity and
    # acceleration use wider windows (2x and 3x) than the smoothing window.
    win = [w, min(2 * w + 1, n - 2) | 1, min(3 * w, n - 2) | 1]
    win = [max(x, poly + 2) for x in win]
    gain = [np.linalg.norm(savgol_coeffs(win[k], poly, deriv=k, delta=dt)) for k in range(3)]

    def sg(X, deriv=0, width=None):
        return savgol_filter(X, width or win[deriv], poly, deriv=deriv, delta=dt, axis=0,
                             mode="interp")

    z = np.column_stack([d["x"], d["y"], d["z"]])
    p = sg(z)
    sr_p = _robust_sigma(z - p, w, poly)
    info = {"window_samples": w, "derived": []}

    if "vx" in d:
        v_raw = np.column_stack([d["vx"], d["vy"], d["vz"]])
        v = sg(v_raw)
        sr_v = _robust_sigma(v_raw - v, w, poly)
        sig_v = sr_v * gain[0]
        # consistency: does the velocity match the slope of the position?
        # Average over ~20 s first so random noise cancels and only a
        # systematic mismatch (wrong frame, airspeed vs ground speed, units) is left.
        m20 = max(1, int(round(20.0 / dt)))
        dv = np.cumsum(v - sg(z, deriv=1), axis=0)
        dv = (dv[m20:] - dv[:-m20]) / m20 if len(dv) > m20 else dv[-1:] / len(dv)
        bias = np.sqrt(np.mean(np.sum(dv ** 2, 1)))
        spd = max(np.mean(np.linalg.norm(v, axis=1)), 1.0)
        if bias > max(0.03 * spd, 3.0):
            print(f"  WARNING: velocity columns differ systematically from d(position)/dt "
                  f"({bias:.1f} m/s RMS, {100 * bias / spd:.0f}% of speed) - check frame/units "
                  "(velocity must be GROUND velocity in the same ENU frame as position).")
    else:
        v = sg(z, deriv=1)
        sr_v, sig_v = np.nan, sr_p * gain[1]
        info["derived"].append("velocity")

    if "ax" in d:
        a_raw = np.column_stack([d["ax"], d["ay"], d["az"]])
        a = sg(a_raw)
        sr_a = _robust_sigma(a_raw - a, w, poly)
        sig_a = sr_a * gain[0]
        da = a - sg(v, deriv=1)
        if np.sqrt(np.mean(np.sum(da ** 2, 1))) > 0.5 * G and \
                np.sqrt(np.mean(np.sum((da - np.array([0, 0, G])) ** 2, 1))) < 0.25 * G:
            print("  WARNING: acceleration looks like it INCLUDES gravity (specific force / "
                  "accelerometer output).  This script expects kinematic acceleration; "
                  "subtract (0, 0, -9.81) or drop the acceleration columns.")
    elif "vx" in d:
        a = sg(v_raw, deriv=1)
        sr_a, sig_a = np.nan, sr_v * gain[1]
        info["derived"].append("acceleration")
    else:
        a = sg(z, deriv=2)
        sr_a, sig_a = np.nan, sr_p * gain[2]
        info["derived"].append("acceleration")

    info.update(dict(p=p, v=v, a=a, z=z,
                     sig_raw=(sr_p, sr_v, sr_a),
                     sig_p=max(sr_p * gain[0], 0.5),
                     sig_v=max(sig_v, 0.2),
                     sig_a=max(sig_a, 0.2)))
    return info


# ---------------------------------------------------------------------------
# 3. Learning from the history (same interface intent_mc expects from
#    imm_tracker.ObservedEnvelope / ManeuverLevelEstimator)
# ---------------------------------------------------------------------------
def flight_frame(v):
    """Per-sample unit vectors: along velocity, horizontal-left, pitch normal."""
    vhat = v / np.maximum(np.linalg.norm(v, axis=1, keepdims=True), 1e-3)
    lat = np.cross(ZHAT, vhat)
    lat /= np.maximum(np.linalg.norm(lat, axis=1, keepdims=True), 1e-6)
    return vhat, lat, np.cross(vhat, lat)


class HistoryEnvelope:
    """What the object has DEMONSTRATED in the history - lower bounds on its
    capability.  Every quantity is taken at a k_sigma lower confidence bound
    and must be held for `persist` seconds (rolling min) to count.

      n_demo     demonstrated load factor [g]           -> n_max  >= n_demo
      bank_demo  demonstrated level-turn bank [rad]      -> bank   >= bank_demo
      V_hi_demo  fastest speed held [m/s]                -> V_max  >= V_hi_demo
      V_lo_demo  slowest speed held [m/s]                -> V_min  <= V_lo_demo
      em_points  {bin: (n, a_x)} demonstrated (load factor, excess accel);
                 point-mass energy balance gives a_thrust >= a_x + k (n^2 - 1)
    """

    def __init__(self, t, v, a, sig_v, sig_a, k_sigma=2.0, persist=2.0, n_bin=0.25):
        dt = float(np.median(np.diff(t)))
        m = max(1, int(round(persist / dt)))
        vhat, lat, _ = flight_frame(v)
        V = np.linalg.norm(v, axis=1)
        n = np.linalg.norm(a + G * ZHAT, axis=1) / G
        n_lo = n - k_sigma * sig_a / G
        a_lat = np.abs(np.sum(a * lat, axis=1))
        bank_lo = np.arctan(np.maximum(a_lat - k_sigma * sig_a, 0.0) / G)
        ax = np.sum(a * vhat, axis=1) + G * v[:, 2] / np.maximum(V, 1.0)
        ax_lo = ax - k_sigma * sig_a

        rmin = lambda x: minimum_filter1d(x, m, mode="nearest")
        rmax = lambda x: maximum_filter1d(x, m, mode="nearest")
        n_held, ax_held = rmin(n_lo), rmin(ax_lo)
        self.n_demo = float(max(1.0, n_held.max()))
        self.bank_demo = float(rmin(bank_lo).max())
        self.V_hi_demo = float(rmin(V - k_sigma * sig_v).max())
        self.V_lo_demo = float(rmax(V + k_sigma * sig_v).min())
        self.ax_demo = float(ax_held.max())
        self.em_points = {}
        for nn, aa in zip(n_held, ax_held):
            b = int(np.floor(max(nn, 1.0) / n_bin))
            if b not in self.em_points or aa > self.em_points[b][1]:
                self.em_points[b] = (max(nn, 1.0), aa)
        self.n_series, self.bank_series = n, np.arctan(a_lat / G)

    def required_thrust(self, k_induced):
        k_induced = np.asarray(k_induced, float)
        req = np.full(k_induced.shape, -np.inf)
        for nn, aa in self.em_points.values():
            req = np.maximum(req, aa + k_induced * (nn ** 2 - 1.0))
        return req

    def summary(self):
        return {"n_demo": self.n_demo, "bank_demo_deg": np.degrees(self.bank_demo),
                "V_lo_demo": self.V_lo_demo, "V_hi_demo": self.V_hi_demo,
                "ax_demo": self.ax_demo}


class HistoryUsage:
    """How hard the object actually maneuvers: RMS lateral acceleration over
    the samples where it is clearly maneuvering, recent data weighted more
    (exponential forgetting, time constant tau).  Measurement variance is
    subtracted so noise isn't mistaken for maneuvering."""

    def __init__(self, t, v, a, sig_a, tau=120.0, floor=3.0, k_sigma=2.0):
        _, lat, _ = flight_frame(v)
        a_lat = np.sum(a * lat, axis=1)
        man = np.abs(a_lat) > max(k_sigma * sig_a, 2.0)
        w = np.exp(-(t[-1] - t) / tau) * man
        if w.sum() > 0:
            ms = np.sum(w * np.maximum(a_lat ** 2 - sig_a ** 2, 0.0)) / w.sum()
            self.sigma_lat = float(max(np.sqrt(ms), floor))
        else:
            self.sigma_lat = float(floor)
        self.frac_maneuvering = float(man.mean())


class HistoryVertical:
    """Climb / descent behaviour learned from the history.

    Finds climb and descent SEGMENTS: runs where the smoothed vertical
    speed stays beyond +/- max(k_sigma * sigma_v, min_rate) for at least
    min_dur seconds (same-direction runs separated by short gaps are
    merged).  From them:

      segments      list of dicts (t0, t1, dh, rate, sign, ongoing)
      ongoing       True if the history ENDS inside a climb/descent
      rate_now      current vertical speed [m/s] (signed) if ongoing
      elapsed       how long the current climb/descent has lasted [s]
      mean_duration mean duration of COMPLETED segments [s]
      dh_samples    altitude changes seen [m] (magnitudes)
      rate_samples  vertical speeds used [m/s] (magnitudes)
      p_up          probability a future change is a climb
                    ((n_climbs + 1) / (n_segments + 2), i.e. 50/50 when
                    there is no evidence)
      hazard        rate of new altitude changes [1/s]
                    = n_segments / (history length + T0); 0 when the
                    history shows no climbs or descents, so a level
                    history gives level forecasts
      climb_demo    demonstrated |vertical speed| (2-sigma lower bound,
                    held for `persist` s) -> lower bound on capability
    """

    def __init__(self, t, h, vz, sig_v, k_sigma=2.0, min_rate=2.0, min_dur=4.0,
                 merge_gap=4.0, persist=2.0, T0=60.0, min_dh=30.0):
        dt = float(np.median(np.diff(t)))
        n = len(t)
        self.threshold = thr = max(k_sigma * sig_v, min_rate)
        s = np.where(vz > thr, 1, np.where(vz < -thr, -1, 0))
        runs, i = [], 0
        while i < n:
            if s[i] == 0:
                i += 1
                continue
            j = i
            while j + 1 < n and s[j + 1] == s[i]:
                j += 1
            runs.append([i, j, int(s[i])])
            i = j + 1
        merged = []
        for r in runs:
            if merged and r[2] == merged[-1][2] and t[r[0]] - t[merged[-1][1]] < merge_gap:
                merged[-1][1] = r[1]
            else:
                merged.append(r)

        self.segments = []
        for i0, i1, sg in merged:
            ongoing = i1 == n - 1
            dur = t[i1] - t[i0]
            dh = h[i1] - h[i0]
            if dur < (min(3.0, min_dur) if ongoing else min_dur) or abs(dh) < min_dh:
                continue
            # steady climb/descent rate: 90th percentile of |vz| in the segment
            # (the mean or median would be dragged down by the level-off)
            self.segments.append(dict(t0=t[i0], t1=t[i1], dh=dh,
                                      rate=float(np.percentile(np.abs(vz[i0:i1 + 1]), 90)),
                                      sign=sg, ongoing=ongoing))
        done = [g for g in self.segments if not g["ongoing"]]
        cur = [g for g in self.segments if g["ongoing"]]
        self.ongoing = bool(cur)
        if self.ongoing:
            m = max(1, int(round(min(3.0, cur[0]["t1"] - cur[0]["t0"]) / dt)))
            self.rate_now = float(np.mean(vz[-m:]))
            self.elapsed = float(cur[0]["t1"] - cur[0]["t0"])
        else:
            self.rate_now, self.elapsed = 0.0, 0.0
        self.mean_duration = float(np.mean([g["t1"] - g["t0"] for g in done])) if done else 0.0
        self.dh_samples = np.array([abs(g["dh"]) for g in self.segments])
        self.rate_samples = np.array([g["rate"] for g in self.segments])
        n_seg, n_up = len(self.segments), sum(g["sign"] > 0 for g in self.segments)
        self.p_up = (n_up + 1.0) / (n_seg + 2.0)
        self.hazard = n_seg / (t[-1] - t[0] + T0) if n_seg else 0.0
        self.dh_cap = 3.0 * max(self.dh_samples.max() if n_seg else 0.0, 300.0)
        m = max(1, int(round(persist / dt)))
        self.climb_demo = float(max(0.0, minimum_filter1d(np.abs(vz) - k_sigma * sig_v, m,
                                                           mode="nearest").max()))

    def describe(self):
        if not self.segments:
            return "no climbs or descents in the history -> altitude held in the forecast"
        txt = ", ".join(f"{'climb' if g['sign'] > 0 else 'descent'} {abs(g['dh']):.0f} m at "
                        f"{g['rate']:.0f} m/s" + (" (ONGOING)" if g["ongoing"] else "")
                        for g in self.segments)
        return (txt + f"; new altitude change every ~{1 / self.hazard:.0f} s on average, "
                f"{100 * self.p_up:.0f}% climbs")


# ---------------------------------------------------------------------------
# 4. Prediction
# ---------------------------------------------------------------------------
def build_intents(dests):
    """Generic hypotheses, plus 'fly to X' for every candidate destination."""
    intents = [Intent("straight", "straight", prior=0.50, mean_duration=180.0),
               Intent("continue turn", "continue_turn", prior=0.25, mean_duration=60.0),
               Intent("evasive", "evasive", prior=0.25, mean_duration=30.0)]
    if dests:
        for it in intents:                        # 50% generic / 50% destinations
            it.prior *= 0.5
        for name, e, n, alt in dests:
            intents.append(Intent(f"to {name}", "fly_to", prior=0.5 / len(dests),
                                  waypoint=(e, n), altitude=alt))
    return intents


class HistoryMonteCarlo(IntentMonteCarlo):
    """IntentMonteCarlo + two additions:

    VERTICAL LAYER (applies to every particle whose lateral intent doesn't
    set an altitude, i.e. all but 'fly to' with a destination altitude):
      * while assimilating the history, each particle holds its own
        flight-path angle, so it follows climbs/descents in the data (the
        ensemble correction keeps it on the track);
      * at the start of the forecast, if the history ends in a climb or
        descent, each particle continues it at the current rate for a
        random remaining time ~ Exponential(mean = max(typical segment
        duration, time it has lasted so far)), then levels off.  ("It has
        been descending for 40 s, so it will probably go on for about that
        long again" - with lots of spread, so short and long are covered);
      * during the forecast, level particles start new altitude changes at
        the rate seen in the history, with sizes/rates resampled from the
        history's climbs and descents (+/- 30% / 20% scatter);
      * climbs follow a constant vertical speed, then capture the target
        altitude smoothly.  Target altitudes stay inside
        [alt_cmd_min, alt_cmd_max] (default: clear of floor/ceiling obstacles).

    OBSTACLES: during the forecast, after every integration sub-step,
    particles inside any obstacle are thrown out (weight -> 0).  Rejection
    removes the WHOLE trajectory, so the forecast is conditioned on "never
    entered an obstacle".  (Not applied while matching the history - the
    measured track is what it is.)
    """

    _MEM = IntentMonteCarlo._MEM + ("h_tgt", "vrate", "dead", "death_t",
                                    "death_x", "death_y", "death_h")

    def __init__(self, intents, vertical=None, obstacles=(), alt_cmd_range=(150.0, 20000.0),
                 **kw):
        super().__init__(intents, **kw)
        self.vert = vertical
        self.obstacles = list(obstacles)
        self.alt_lo, self.alt_hi = alt_cmd_range
        self.has_alt = np.array([it.altitude is not None for it in self.intents])
        self.vertical_tracking = True
        self.enforce_obstacles = False                   # switched on by start_forecast
        self.n_killed = 0

    # -- set-up ---------------------------------------------------------------
    def _init_capability(self, env):
        """Add the demonstrated climb rate to the class scoring and as a
        lower bound on each particle's climb-rate capability."""
        climb = self.vert.climb_demo if (self.vert is not None and env is not None) else 0.0
        prior0 = self.class_prior
        if climb > 0 and len(self.classes) > 1:
            ll = np.array([norm.logcdf((c.range("climb_rate_max")[1] - climb) / 3.0)
                           for c in self.classes])
            p = prior0 * np.exp(ll - ll.max())
            self.class_prior = p / p.sum()
        super()._init_capability(env)
        self.class_prior = prior0
        if climb > 0:
            self._lb["climb_rate_max"] = climb
            self.theta["climb_rate_max"] = np.maximum(self.theta["climb_rate_max"], climb)

    def initialize_from_imm(self, x, P, t0=0.0, envelope=None, usage=None):
        super().initialize_from_imm(x, P, t0=t0, envelope=envelope, usage=usage)
        N = self.N
        self.h_tgt, self.vrate = self.S["h"].copy(), np.zeros(N)
        self.dead = np.zeros(N, bool)
        for k in ("death_t", "death_x", "death_y", "death_h"):
            setattr(self, k, np.full(N, np.nan))
        self.vertical_tracking = True

    def start_forecast(self):
        """Switch from 'follow the data' to forecast behaviour: vertical
        layer and obstacle rejection on."""
        self.vertical_tracking = False
        self.enforce_obstacles = True
        S, N, v = self.S, self.N, self.vert
        self.h_tgt, self.vrate = S["h"].copy(), np.zeros(N)
        if v is not None and v.ongoing:
            idx = np.flatnonzero(~self.has_alt[self.intent])
            T = self.rng.exponential(max(v.mean_duration, v.elapsed, 10.0), idx.size)
            rate = abs(v.rate_now) * np.exp(0.1 * self.rng.standard_normal(idx.size))
            dh = np.minimum(rate * T, v.dh_cap)
            self.h_tgt[idx] = np.clip(S["h"][idx] + np.sign(v.rate_now) * dh,
                                      self.alt_lo, self.alt_hi)
            self.vrate[idx] = rate

    # -- vertical guidance ------------------------------------------------------
    def _new_altitude_change(self, idx):
        v, n = self.vert, idx.size
        sign = np.where(self.rng.random(n) < v.p_up, 1.0, -1.0)
        dh = self.rng.choice(v.dh_samples, n) * np.exp(0.3 * self.rng.standard_normal(n))
        rate = self.rng.choice(v.rate_samples, n) * np.exp(0.2 * self.rng.standard_normal(n))
        self.h_tgt[idx] = np.clip(self.S["h"][idx] + sign * dh, self.alt_lo, self.alt_hi)
        self.vrate[idx] = rate

    def _vertical_events(self, dt):
        v = self.vert
        if v is None or v.hazard <= 0:
            return
        level = np.abs(self.h_tgt - self.S["h"]) < 50.0
        free = ~self.has_alt[self.intent] & ~self.dead & level
        idx = np.flatnonzero(free & (self.rng.random(self.N) < -np.expm1(-dt * v.hazard)))
        if idx.size:
            self._new_altitude_change(idx)

    def _commands(self, dt):
        phi_cmd, h_cmd, V_cmd = super()._commands(dt)
        S, K_h = self.S, self.perf.K_h
        free = ~self.has_alt[self.intent]
        if self.vertical_tracking:                      # hold own flight-path angle
            vz = S["V"] * np.sin(S["gam"])
            h_cmd[free] = S["h"][free] + vz[free] / K_h
        else:                                           # constant-rate change, then capture
            lim = np.where(self.vrate > 0, self.vrate / K_h, np.inf)
            dh = np.clip(self.h_tgt - S["h"], -lim, lim)
            h_cmd[free] = S["h"][free] + dh[free]
            self.h_tgt[~free] = S["h"][~free]           # level where 'fly to' hands back
        return phi_cmd, h_cmd, V_cmd

    # -- propagation with obstacle checks ---------------------------------------
    def propagate(self, dt, allow_switching=True, wind=None):
        if allow_switching:
            self._switch_intents(dt)
        if not self.vertical_tracking:
            self._vertical_events(dt)
        if wind is None:
            wind = (self.wE, self.wN, 0.0)
        n_sub = max(1, int(round(dt / self.substep)))
        h = dt / n_sub
        perf = self._perf_view()
        for _ in range(n_sub):
            phi_cmd, h_cmd, V_cmd = self._commands(h)
            point_mass_step(self.S, phi_cmd, h_cmd, V_cmd, self.theta["bank"], perf, h, wind)
            self.t += h
            self._check_obstacles()

    def _check_obstacles(self):
        if not (self.obstacles and self.enforce_obstacles):
            return
        hit = ~self.dead & inside_any(self.obstacles, self.positions())
        if not hit.any():
            return
        self.dead |= hit
        self.n_killed += int(hit.sum())
        self.death_t[hit] = self.t
        self.death_x[hit], self.death_y[hit], self.death_h[hit] = \
            self.S["x"][hit], self.S["y"][hit], self.S["h"][hit]
        self.logw[hit] = -np.inf
        lse = logsumexp(self.logw)
        if not np.isfinite(lse):
            raise RuntimeError("every trajectory entered an obstacle - check the obstacle "
                               "definitions (is the object already inside one?)")
        self.logw -= lse

    def predict(self, horizon, record_dt=10.0, allow_switching=True, wind=None):
        """As IntentMonteCarlo.predict, plus where/when trajectories were
        thrown out during the forecast (fc.death_pos, fc.death_t), the
        probability removed (fc.p_rejected) and the effective sample size."""
        sim = copy.deepcopy(self)
        t0 = sim.t
        w0 = np.exp(sim.logw)
        n_rec = int(round(horizon / record_dt))
        t_rec = np.arange(1, n_rec + 1) * record_dt
        pos = np.empty((n_rec, self.N, 3))
        for k in range(n_rec):
            sim.propagate(record_dt, allow_switching=allow_switching, wind=wind)
            pos[k] = sim.positions()
        fc = Forecast(t_rec, pos, np.exp(sim.logw), sim.intent.copy(), self.names)
        new = sim.dead & (sim.death_t > t0)
        fc.death_pos = np.column_stack([sim.death_x, sim.death_y, sim.death_h])[new]
        fc.death_t = sim.death_t[new] - t0
        fc.p_rejected = float(w0[new].sum())
        fc.ess = float(1.0 / np.sum(fc.w ** 2))
        fc.alive = fc.w > 0
        return fc


def refresh_holds(mc):
    """After intent inference, re-anchor the 'hold' targets to each
    particle's CURRENT state.  The holds were set when the particles were
    started (window seconds ago); the ensemble correction moves the state
    but not the holds, so without this 'straight' particles would steer
    back to an old heading/altitude/speed at the start of the forecast."""
    S = mc.S
    kinds = np.array([it.kind for it in mc.intents])[mc.intent]
    has_alt = np.array([it.altitude is not None for it in mc.intents])[mc.intent]
    has_spd = np.array([it.speed is not None for it in mc.intents])[mc.intent]
    st = kinds == "straight"
    mc.psi_hold[st] = S["psi"][st]
    mc.psi_wander[st] = 0.0
    mc.h_hold[~has_alt] = S["h"][~has_alt]
    mc.V_hold[~has_spd] = S["V"][~has_spd] * mc.V_scale[~has_spd]


def command_altitude_range(obstacles, margin=150.0, max_alt=20000.0):
    """Altitude targets for climbs/descents stay `margin` clear of any
    floor / ceiling obstacle (a pilot doesn't aim for the ground).  Only
    TARGETS are limited - a trajectory can still overshoot into an
    obstacle, and is then thrown out."""
    floors = [o.alt for o in obstacles if o.is_floor]
    ceils = [o.alt for o in obstacles if o.is_ceiling]
    lo = max(floors) + margin if floors else -np.inf
    hi = min(ceils) - margin if ceils else max_alt
    return lo, hi


def run_prediction(hist, sm, horizon, n_particles=3000, window=60.0, assim_dt=2.0,
                   dests=(), known_perf=False, seed=0, record_dt=None, obstacles=(),
                   vertical=True, alt_margin=150.0):
    t = hist["t"]
    dt = float(np.median(np.diff(t)))
    window = float(min(window, 0.5 * (t[-1] - t[0])))
    k0 = int(np.searchsorted(t, t[-1] - window))
    env = HistoryEnvelope(t, sm["v"], sm["a"], sm["sig_v"], sm["sig_a"])
    usage = HistoryUsage(t, sm["v"], sm["a"], sm["sig_a"])
    vert = HistoryVertical(t, sm["p"][:, 2], sm["v"][:, 2], sm["sig_v"]) if vertical else None

    x0 = np.concatenate([sm["p"][k0], sm["v"][k0], sm["a"][k0]])
    P0 = np.diag([sm["sig_p"] ** 2] * 3 + [sm["sig_v"] ** 2] * 3 + [sm["sig_a"] ** 2] * 3)
    sig_meas = max(sm["sig_raw"][0], 1.0)
    R = np.eye(3) * sig_meas ** 2

    kw = {} if known_perf else {"classes": default_classes()}
    mc = HistoryMonteCarlo(build_intents(dests), vertical=vert, obstacles=obstacles,
                           alt_cmd_range=command_altitude_range(obstacles, alt_margin),
                           n_particles=n_particles, seed=seed, **kw)
    mc.initialize_from_imm(x0, P0, t0=t[k0],
                           envelope=None if known_perf else env, usage=usage)
    step = max(1, int(round(assim_dt / dt)))
    idx = list(range(k0 + step, len(t), step))
    if not idx or idx[-1] != len(t) - 1:
        idx.append(len(t) - 1)
    t_prev = t[k0]
    for k in idx:
        mc.assimilate(sm["z"][k], R, dt=t[k] - t_prev)
        t_prev = t[k]
    refresh_holds(mc)
    now = sm["p"][-1:]
    inside = [o.label() for o in obstacles if o.inside(now)[0]]
    if inside:
        raise ValueError(f"the last data point (E {now[0, 0]:.0f}, N {now[0, 1]:.0f}, "
                         f"alt {now[0, 2]:.0f} m) is already inside obstacle(s): "
                         f"{', '.join(inside)} - every trajectory would be thrown out. "
                         "Check the obstacle definitions.")
    mc.start_forecast()
    if not vertical:                                    # hold altitude, no events
        mc.vert = None
        mc.h_tgt, mc.vrate = mc.S["h"].copy(), np.zeros(mc.N)

    if record_dt is None:
        record_dt = horizon / max(3, int(round(horizon / 10.0)))
    fc = mc.predict(horizon, record_dt=record_dt)
    return dict(mc=mc, fc=fc, env=env, usage=usage, vert=vert, t_handoff=t[k0],
                window=window, t_end=t[-1], sig_meas=sig_meas, obstacles=list(obstacles))


# ---------------------------------------------------------------------------
# Density regions of a (multi-modal) 2-D cloud
# ---------------------------------------------------------------------------
def hpd_grid(xy, w, labels, levels=(0.5, 0.95), n_grid=180, max_pts=1500, seed=0):
    """Mixture-of-KDE (one KDE per intent) density on a grid, and the density
    thresholds that enclose `levels` of the probability (highest-density
    regions - the multi-modal analogue of 50% / 95% ellipses)."""
    rng = np.random.default_rng(seed)
    lo, hi = xy.min(0), xy.max(0)
    pad = 0.3 * (hi - lo) + 1e-3
    gx = np.linspace(lo[0] - pad[0], hi[0] + pad[0], n_grid)
    gy = np.linspace(lo[1] - pad[1], hi[1] + pad[1], n_grid)
    GX, GY = np.meshgrid(gx, gy)
    grid = np.column_stack([GX.ravel(), GY.ravel()])

    def dens(pts):
        out = np.zeros(len(pts))
        for j in np.unique(labels):
            m = np.flatnonzero(labels == j)
            pj = w[m].sum()
            if pj < 1e-3 or m.size < 20:
                continue
            if m.size > max_pts:
                m, wj = rng.choice(m, max_pts, replace=False, p=w[m] / pj), None
            else:
                wj = w[m] / pj
            data = xy[m].T + 1e-6 * rng.standard_normal((2, m.size))
            out += pj * gaussian_kde(data, weights=wj)(pts.T)
        return out

    D = dens(grid).reshape(GX.shape)
    ev = rng.choice(len(w), min(3000, len(w)), p=w)
    d_part = dens(xy[ev])
    thr = {L: float(np.quantile(d_part, 1.0 - L)) for L in levels}
    cell = (gx[1] - gx[0]) * (gy[1] - gy[0])
    area = {L: float((D >= thr[L]).sum() * cell) for L in levels}
    return GX, GY, D, thr, area, dens


# ---------------------------------------------------------------------------
# 5. Plot
# ---------------------------------------------------------------------------
INTENT_COLORS = ["#6b6b6b", "#8e44ad", "#d4a017", "#1f6fd1", "#2a9d5c", "#c0392b",
                 "#e67e22", "#16a085"]


def plot_cloud(hist, sm, res, horizon, out_png, dests=(), truth=None, n_show=2500):
    fc, mc = res["fc"], res["mc"]
    k = fc.index(horizon)
    h_act = fc.t[k]
    pos = fc.pos[k] / 1e3                                    # km
    rng = np.random.default_rng(3)
    show = rng.choice(len(fc.w), n_show, p=fc.w)            # rejected ones have weight 0
    alive = fc.w > 0
    GX, GY, D, thr, area, dens = hpd_grid(pos[alive, :2], fc.w[alive], fc.intent[alive])
    obstacles = res.get("obstacles", [])
    mean = fc.mean(k) / 1e3
    best = fc.map_mean(k) / 1e3
    p_int = fc.intent_probabilities()
    p_int0 = mc.intent_probabilities()

    fig = plt.figure(figsize=(15, 8.2))
    gs = fig.add_gridspec(2, 2, width_ratios=[2.1, 1.0], height_ratios=[1.0, 1.0],
                          wspace=0.22, hspace=0.55)
    ax = fig.add_subplot(gs[:, 0])
    axh = fig.add_subplot(gs[0, 1])
    axi = fig.add_subplot(gs[1, 1])

    # --- map
    p_hist = sm["p"] / 1e3
    in_win = hist["t"] >= res["t_handoff"]
    ax.plot(p_hist[:, 0], p_hist[:, 1], color="#9a9a9a", lw=1.4, label="history (smoothed)")
    ax.plot(p_hist[in_win, 0], p_hist[in_win, 1], color="#333333", lw=2.2,
            label=f"last {res['window']:.0f} s (used for intent inference)")
    ax.plot(*p_hist[-1, :2], "o", color="k", ms=8, label="last data point")

    for frac in (1 / 3, 2 / 3):                              # faint earlier clouds
        kk = fc.index(frac * horizon)
        if kk == k:
            continue
        s2 = rng.choice(len(fc.w), 800, p=fc.w)
        ax.scatter(fc.pos[kk][s2, 0] / 1e3, fc.pos[kk][s2, 1] / 1e3, s=1.5,
                   color="#b8b8b8", alpha=0.35, zorder=1)
        ax.annotate(f"+{fc.t[kk]:.0f} s", np.median(fc.pos[kk][s2, :2], 0) / 1e3,
                    fontsize=8, color="#808080")

    for j in range(len(fc.names)):
        s = show[fc.intent[show] == j]
        if s.size:
            ax.scatter(pos[s, 0], pos[s, 1], s=3, alpha=0.45, color=INTENT_COLORS[j % 8],
                       zorder=2)
    # levels must ascend: the 95% threshold is the LOWER density
    ax.contour(GX, GY, D, levels=[thr[0.95], thr[0.5]], colors=["k", "k"],
               linestyles=["-", "--"], linewidths=[1.6, 1.2], zorder=3)
    # obstacles (footprints) and where trajectories were thrown out
    for ob in obstacles:
        art = ob.draw(ax, 1e-3, facecolor="#8d6e63", edgecolor="#5d4037", alpha=0.22,
                      hatch="//", lw=1.2, zorder=0)
        if art is not None and ob.kind != "terrain":
            zt = "" if not np.isfinite(getattr(ob, "z_max", np.inf)) else \
                f"\nto {ob.z_max / 1e3:.1f} km"
            c = (ob.c if ob.kind == "cylinder" else ob.v.mean(0) if ob.kind == "polygon"
                 else 0.5 * (ob.lo[:2] + ob.hi[:2]))
            ax.annotate(ob.label() + zt, c / 1e3, fontsize=8, ha="center", color="#5d4037",
                        weight="bold", zorder=6)
    hit = fc.death_t <= h_act + 1e-6
    if hit.any():
        dp = fc.death_pos[hit]
        if len(dp) > 800:
            dp = dp[rng.choice(len(dp), 800, replace=False)]
        ax.scatter(dp[:, 0] / 1e3, dp[:, 1] / 1e3, marker="x", s=10, lw=0.8,
                   color="#c0392b", alpha=0.35, zorder=2)
    ax.plot(*mean[:2], "P", color="white", mec="k", ms=12, zorder=5)
    ax.plot(*best[:2], "D", color="#f1c40f", mec="k", ms=9, zorder=5)

    if truth is not None:
        tt = truth[:, 0] - res["t_end"]
        fut = (tt >= 0) & (tt <= h_act)
        ax.plot(truth[fut, 1] / 1e3, truth[fut, 2] / 1e3, color="#c0392b", lw=1.6,
                ls=":", zorder=4)
        tr = np.array([np.interp(h_act, tt, truth[:, c]) for c in (1, 2, 3)]) / 1e3
        ax.plot(tr[0], tr[1], "X", color="#c0392b", mec="k", ms=12, zorder=6)
        inside = {L: bool(dens(np.atleast_2d(tr[:2]))[0] >= thr[L]) for L in thr}
        res["truth_inside"] = inside
        res["truth_err_km"] = (np.linalg.norm(tr - mean), np.linalg.norm(tr - best))

    for name, e, n, _ in dests:
        ax.plot(e / 1e3, n / 1e3, "*", ms=16, color="#222222", zorder=6)
        ax.annotate(name, (e / 1e3, n / 1e3), xytext=(6, 6), textcoords="offset points",
                    fontsize=12, weight="bold")

    handles = [Line2D([], [], color="#9a9a9a", lw=1.4, label="history (smoothed)"),
               Line2D([], [], color="#333333", lw=2.2,
                      label=f"last {res['window']:.0f} s (intent inference)"),
               Line2D([], [], marker="o", color="k", ls="", label="last data point")]
    handles += [Line2D([], [], marker="o", color=INTENT_COLORS[j % 8], ls="", ms=6,
                       label=f"{nm}  ({100 * p_int[j]:.0f}%)")
                for j, nm in enumerate(fc.names) if p_int[j] > 0.005]
    handles += [Line2D([], [], color="k", ls="--", label=f"50% region ({area[0.5]:.0f} km²)"),
                Line2D([], [], color="k", ls="-", label=f"95% region ({area[0.95]:.0f} km²)"),
                Line2D([], [], marker="P", color="white", mec="k", ls="", ms=10,
                       label="cloud mean"),
                Line2D([], [], marker="D", color="#f1c40f", mec="k", ls="", ms=8,
                       label="likeliest-intent mean")]
    if truth is not None:
        handles += [Line2D([], [], color="#c0392b", ls=":", marker="X", mec="k", ms=9,
                           label="actual path / position")]
    if any(o.kind not in ("floor", "ceiling", "terrain") for o in obstacles):
        handles += [Rectangle((0, 0), 1, 1, facecolor="#8d6e63", edgecolor="#5d4037",
                              alpha=0.3, hatch="//", label="obstacle (footprint)")]
    for o in obstacles:
        if o.kind == "terrain":
            handles += [Line2D([], [], color="#5d4037", lw=0.9,
                               label=f"{o.label()} (terrain height contours)")]
    if hit.any():
        handles += [Line2D([], [], marker="x", color="#c0392b", ls="", ms=6,
                           label=f"trajectory thrown out ({100 * fc.p_rejected:.0f}% of "
                                 "probability)")]
    ax.legend(handles=handles, fontsize=8, loc="best", framealpha=0.9)
    ax.set_aspect("equal", adjustable="datalim")
    ax.set_xlabel("East [km]")
    ax.set_ylabel("North [km]")
    ax.grid(alpha=0.3)
    ax.set_title(f"Predicted positions {h_act:.0f} s after the last data point "
                 f"({mc.N} particles, {int(alive.sum())} kept)\n"
                 "faint grey: clouds at earlier times", fontsize=11)

    # --- altitude fan vs time
    th = hist["t"] - res["t_end"]
    axh.plot(th, sm["p"][:, 2] / 1e3, color="#333333", lw=1.5)
    q = np.array([[np.quantile(fc.pos[i][:, 2], qq, method="inverted_cdf",
                               weights=fc.w) for qq in (0.025, 0.25, 0.5, 0.75, 0.975)]
                  for i in range(len(fc.t))]) / 1e3
    tf = np.concatenate([[0.0], fc.t])
    q = np.vstack([np.full(5, sm["p"][-1, 2] / 1e3), q])
    axh.fill_between(tf, q[:, 0], q[:, 4], color="#1f6fd1", alpha=0.18, label="95%")
    axh.fill_between(tf, q[:, 1], q[:, 3], color="#1f6fd1", alpha=0.35, label="50%")
    axh.plot(tf, q[:, 2], color="#1f6fd1", lw=2, label="median")
    if truth is not None:
        axh.plot(truth[:, 0] - res["t_end"], truth[:, 3] / 1e3, color="#c0392b", ls=":",
                 lw=1.6, label="actual")
    for ob in obstacles:
        if ob.is_floor or ob.is_ceiling:
            lim = (axh.get_ylim()[0] - 1, ob.alt / 1e3) if ob.is_floor else \
                (ob.alt / 1e3, axh.get_ylim()[1] + 1)
            axh.axhspan(*lim, facecolor="#8d6e63", alpha=0.25, hatch="//", lw=0)
            axh.axhline(ob.alt / 1e3, color="#5d4037", lw=1.2)
    yl = np.concatenate([q.ravel(), sm["p"][:, 2] / 1e3])
    pad = 0.08 * (yl.max() - yl.min()) + 0.05
    axh.set_ylim(yl.min() - pad, yl.max() + pad)
    axh.axvline(0, color="k", lw=0.8)
    axh.set_xlim(th[0], h_act * 1.02)
    axh.set_xlabel("time relative to last data point [s]")
    axh.set_ylabel("altitude [km]")
    axh.set_title("Altitude", fontsize=10)
    axh.grid(alpha=0.3)
    axh.legend(fontsize=7, loc="best")

    # --- intent probabilities
    y = np.arange(len(fc.names))
    axi.barh(y + 0.2, 100 * p_int0, 0.4, color="#9ab7e0", label="now (after inference)")
    axi.barh(y - 0.2, 100 * p_int, 0.4, color="#1f6fd1", label=f"at +{h_act:.0f} s")
    axi.set_yticks(y, fc.names)
    axi.invert_yaxis()
    axi.set_xlabel("probability [%]")
    axi.set_title("Intent hypotheses\n(at +horizon includes plan changes)", fontsize=10)
    axi.grid(alpha=0.3, axis="x")
    axi.legend(fontsize=7, loc="lower right")

    fig.savefig(out_png, dpi=140, bbox_inches="tight")
    plt.close(fig)
    res["area_km2"] = area
    return res


# ---------------------------------------------------------------------------
# Demo data (only used when no --csv is given)
# ---------------------------------------------------------------------------
def make_demo(hist_path, truth_path, t_hist=240.0, t_future=300.0, seed=7,
              future_bank_deg=-45.0, future_turn=(30.0, 60.0), descent_to=3000.0,
              descent_rate=30.0):
    """Fighter-like target: hard turn, S-turns, climb to 6.5 km, gentle turn,
    then a descent that is STILL GOING when the history ends (it levels at
    `descent_to` in the future).  After the history ends it also makes a
    45 deg-bank left turn.  Writes a noisy history CSV (p, v, a) and the
    noise-free future truth."""
    perf = AircraftPerformance(n_max=7.0, a_thrust_max=6.0, k_induced=0.25,
                               roll_rate_max_deg=180.0, climb_rate_max=80.0, K_psi=1.5)
    wind = (10.0, -6.0, 0.0)
    dt = 0.05
    S = {"x": np.zeros(1), "y": np.zeros(1), "h": np.full(1, 5000.0), "V": np.full(1, 240.0),
         "gam": np.zeros(1), "psi": np.radians([90.0]), "phi": np.zeros(1)}
    psi_hold, h_tgt, v_rate = S["psi"].copy(), 5000.0, 40.0
    rows = []
    for i in range(int(round((t_hist + t_future) / dt)) + 1):
        t = i * dt
        cg = np.cos(S["gam"][0])
        rows.append([t, S["x"][0], S["y"][0], S["h"][0],
                     S["V"][0] * cg * np.sin(S["psi"][0]) + wind[0],
                     S["V"][0] * cg * np.cos(S["psi"][0]) + wind[1],
                     S["V"][0] * np.sin(S["gam"][0])])
        lim = np.radians([80.0])
        if 30 <= t < 50:
            phi_cmd = -np.array([np.arccos(1 / 5.0)])                  # 5 g left turn
        elif 90 <= t < 120:
            b = np.arccos(1 / 4.0)                                     # 4 g S-turns
            phi_cmd = np.array([b if int((t - 90) // 7.5) % 2 == 0 else -b])
        elif 150 <= t < 190:
            phi_cmd = np.radians([30.0])                               # gentle right turn
        elif t_hist + future_turn[0] <= t < t_hist + future_turn[1]:
            phi_cmd = np.radians([future_bank_deg])                    # future: turn
        else:
            phi_cmd = perf.K_psi * wrap_pi(psi_hold - S["psi"])
        if not (t < 30 or 50 <= t < 90 or 120 <= t < 150
                or 190 <= t < t_hist + future_turn[0] or t >= t_hist + future_turn[1]):
            psi_hold = S["psi"].copy()
        if t >= 120:
            h_tgt, v_rate = 6500.0, 40.0                               # climb at 40 m/s
        if t >= 200:
            h_tgt, v_rate = descent_to, descent_rate                   # descent from 200 s
        lim_h = v_rate / perf.K_h
        h_cmd = S["h"] + np.clip(h_tgt - S["h"], -lim_h, lim_h)        # constant-rate change
        point_mass_step(S, phi_cmd, h_cmd, np.full(1, 240.0), lim, perf, dt, wind)
    T = np.array(rows)
    acc = np.gradient(T[:, 4:7], dt, axis=0)
    stride = int(round(0.5 / dt))                                      # 2 Hz data
    hist_mask = T[:, 0] <= t_hist + 1e-9
    H = np.hstack([T[hist_mask][::stride, :7], acc[hist_mask][::stride]])
    rng = np.random.default_rng(seed)
    H[:, 1:4] += rng.normal(0, 15.0, (len(H), 3))                      # 15 m position noise
    H[:, 4:7] += rng.normal(0, 2.0, (len(H), 3))                       # 2 m/s
    H[:, 7:10] += rng.normal(0, 1.5, (len(H), 3))                      # 1.5 m/s^2
    np.savetxt(hist_path, H, delimiter=",", fmt="%.4f",
               header="t,x,y,z,vx,vy,vz,ax,ay,az", comments="")
    np.savetxt(truth_path, T[~hist_mask][::stride, :4], delimiter=",", fmt="%.4f",
               header="t,x,y,z", comments="")


def write_demo_obstacles(path):
    """Ground at 0 m plus a ridge (polygon footprint, top 3.8 km) and a
    restricted-airspace cylinder, placed across the demo's likely paths."""
    obs = [{"type": "floor", "alt": 0.0, "name": "ground"},
           {"type": "polygon", "name": "ridge", "z_min": 0.0, "z_max": 3800.0,
            "vertices": [[-62000, -2000], [-56000, -3000], [-51000, 26000],
                         [-57000, 27000]]},
           {"type": "cylinder", "name": "restricted", "center": [-45000, -30000],
            "radius": 6000.0}]
    with open(path, "w") as f:
        json.dump(obs, f, indent=2)


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1],
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--csv", help="history CSV (t,x,y,z[,vx,vy,vz][,ax,ay,az]); "
                                  "omit to run the built-in demo")
    ap.add_argument("--horizon", type=float, default=180.0, help="seconds ahead [180]")
    ap.add_argument("--particles", type=int, default=3000)
    ap.add_argument("--window", type=float, default=60.0,
                    help="seconds of recent data used for intent inference [60]")
    ap.add_argument("--assim-dt", type=float, default=2.0,
                    help="interval between assimilated positions [s]")
    ap.add_argument("--smooth", type=float, default=3.0,
                    help="smoothing window [s] for noise estimation [3]")
    ap.add_argument("--dest", nargs=4, action="append", default=[],
                    metavar=("NAME", "EAST_M", "NORTH_M", "ALT_M"),
                    help="candidate destination (repeatable)")
    ap.add_argument("--known-perf", action="store_true",
                    help="use the fixed default AircraftPerformance instead of learning "
                         "capability from the history")
    ap.add_argument("--obstacles", help="JSON file of obstacle regions (see obstacles.py); "
                                        "trajectories entering one are thrown out")
    ap.add_argument("--floor", default="0",
                    help="altitude [m] below which trajectories are thrown out "
                         "('none' to disable) [0]")
    ap.add_argument("--alt-margin", type=float, default=150.0,
                    help="climb/descent targets stay this far [m] above the floor / "
                         "below a ceiling [150]")
    ap.add_argument("--no-vertical", action="store_true",
                    help="ignore climbs/descents in the history (always hold altitude)")
    ap.add_argument("--truth", help="optional CSV (t,x,y,z) of what actually happened, "
                                    "for overlay/validation")
    ap.add_argument("--out", default="trajectory_cloud", help="output file prefix")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    dests = [(n, float(e), float(nn), float(a)) for n, e, nn, a in args.dest]
    if args.csv is None:
        args.csv, args.truth = "demo_history.csv", "demo_truth_future.csv"
        make_demo(args.csv, args.truth)
        if args.obstacles is None:
            args.obstacles = "demo_obstacles.json"
            write_demo_obstacles(args.obstacles)
        print(f"No --csv given: wrote demo data to {args.csv} (+ {args.truth}, "
              f"{args.obstacles})")

    obstacles = load_obstacles(args.obstacles) if args.obstacles else []
    if args.floor.lower() != "none" and not any(o.is_floor for o in obstacles):
        obstacles.insert(0, Floor(float(args.floor)))
    if obstacles:
        print("Obstacles: " + "; ".join(o.label() for o in obstacles))

    print(f"\nLoading {args.csv}")
    hist, dt = make_uniform(load_history(args.csv))
    sm = smooth_history(hist, dt, smooth_s=args.smooth)
    t = hist["t"]
    sr = sm["sig_raw"]
    print(f"  {len(t)} samples, {t[-1] - t[0]:.0f} s at dt = {dt:.3f} s")
    if sm["derived"]:
        print(f"  derived from position: {', '.join(sm['derived'])}")
    print("  estimated noise per sample (1-sigma, per axis): "
          f"position {sr[0]:.1f} m"
          + (f", velocity {sr[1]:.2f} m/s" if np.isfinite(sr[1]) else "")
          + (f", acceleration {sr[2]:.2f} m/s^2" if np.isfinite(sr[2]) else ""))

    print(f"\nPredicting {args.horizon:.0f} s ahead with {args.particles} particles ...")
    try:
        res = run_prediction(hist, sm, args.horizon, n_particles=args.particles,
                             window=args.window, assim_dt=args.assim_dt, dests=dests,
                             known_perf=args.known_perf, seed=args.seed, obstacles=obstacles,
                             vertical=not args.no_vertical, alt_margin=args.alt_margin)
    except (ValueError, RuntimeError) as err:
        raise SystemExit(f"ERROR: {err}")
    truth = np.genfromtxt(args.truth, delimiter=",", skip_header=1) if args.truth else None
    png = f"{args.out}.png"
    res = plot_cloud(hist, sm, res, args.horizon, png, dests=dests, truth=truth)

    # --- report
    mc, fc, env, usage = res["mc"], res["fc"], res["env"], res["usage"]
    k = fc.index(args.horizon)
    es = env.summary()
    print("\nLearned from the history (lower bounds on capability):")
    print(f"  load factor >= {es['n_demo']:.2f} g, level-turn bank >= "
          f"{es['bank_demo_deg']:.0f} deg, speed held {es['V_lo_demo']:.0f}-"
          f"{es['V_hi_demo']:.0f} m/s")
    print(f"  maneuvering {100 * usage.frac_maneuvering:.0f}% of the time, RMS lateral "
          f"accel while maneuvering {usage.sigma_lat:.1f} m/s^2")
    if not args.known_perf:
        print("  platform class: " + ", ".join(
            f"{n} {100 * p:.0f}%" for n, p in zip(mc.class_names, mc.class_probabilities())))
        if mc.prior_exceeded:
            print(f"  NOTE: demonstrated {mc.prior_exceeded} exceeds every class prior - "
                  "the forecast relies on the demonstrated values (+25% headroom)")
    if res["vert"] is not None:
        print(f"  vertical: {res['vert'].describe()}")
        if res["vert"].ongoing:
            print(f"    -> history ends {'climbing' if res['vert'].rate_now > 0 else 'descending'}"
                  f" at {abs(res['vert'].rate_now):.0f} m/s for {res['vert'].elapsed:.0f} s so far;"
                  " forecast continues it for a random remaining time")
    if obstacles:
        print(f"\nObstacles: {100 * fc.p_rejected:.1f}% of the forecast probability thrown "
              f"out (effective sample size now {fc.ess:.0f} of {mc.N})")
        if fc.ess < 300:
            print("  NOTE: few effective samples left - increase --particles")
    print("\nIntent probabilities (now -> at horizon):")
    for nm, p0, p1 in zip(fc.names, mc.intent_probabilities(), fc.intent_probabilities()):
        print(f"  {nm:<16} {100 * p0:5.1f}%  ->  {100 * p1:5.1f}%")
    m = fc.mean(k)
    last = sm["p"][-1]
    print(f"\nAt +{fc.t[k]:.0f} s:")
    print(f"  cloud mean E {m[0] / 1e3:.2f} km, N {m[1] / 1e3:.2f} km, alt {m[2] / 1e3:.2f} km "
          f"({np.linalg.norm(m[:2] - last[:2]) / 1e3:.1f} km from last point)")
    print(f"  50% region {res['area_km2'][0.5]:.0f} km^2, 95% region "
          f"{res['area_km2'][0.95]:.0f} km^2 (horizontal)")
    if "truth_inside" in res:
        e_mean, e_best = res["truth_err_km"]
        ins = res["truth_inside"]
        print(f"  actual position: {e_mean:.1f} km from cloud mean, {e_best:.1f} km from "
              f"likeliest-intent mean; inside 50% region: {ins[0.5]}, inside 95%: {ins[0.95]}")

    csv_out = f"{args.out}_t{fc.t[k]:.0f}s.csv"
    keep = fc.w > 0                                          # thrown-out trajectories omitted
    np.savetxt(csv_out, np.column_stack([fc.pos[k], fc.w, fc.intent])[keep], delimiter=",",
               fmt=["%.2f", "%.2f", "%.2f", "%.4e", "%d"],
               header="east_m,north_m,up_m,weight,intent_index  # intents: "
                      + "; ".join(f"{j}={n}" for j, n in enumerate(fc.names)), comments="")
    print(f"\nSaved: {png}, {csv_out}")


if __name__ == "__main__":
    main()
