"""
obstacles.py
============
Regions a predicted trajectory is NOT allowed to enter.  Any Monte Carlo
trajectory that passes into one is thrown out (its weight is set to zero),
so the forecast cloud only contains trajectories that stay clear.

All coordinates are local ENU [m]: x = East, y = North, z = Up.

Obstacle types (JSON form shown; load a list of them with load_obstacles)
------------------------------------------------------------------------
  {"type": "floor",    "alt": 0}                      z below alt
  {"type": "ceiling",  "alt": 15000}                  z above alt
  {"type": "box",      "min": [E, N, U], "max": [E, N, U]}
  {"type": "cylinder", "center": [E, N], "radius": R,
                       "z_min": 0, "z_max": 3000}     (z limits optional)
  {"type": "polygon",  "vertices": [[E, N], [E, N], ...],
                       "z_min": 0, "z_max": 4500}     extruded polygon
  {"type": "terrain",  "file": "terrain.npz"}         below a height grid
       or inline:      "e": [...], "n": [...], "elev": [[...], ...]
       (elev[i][j] is the height at n[i], e[j]; outside the grid = no terrain)

Every entry may also have "name" (used in plots and messages).

Usage
-----
    obs = load_obstacles("obstacles.json")
    hit = inside_any(obs, P)          # P (N, 3) -> bool (N,)

Methods and references
----------------------
* Rejection.  Throwing out trajectories that enter a region is the
  acceptance/rejection way of imposing state constraints on a particle
  filter or Monte Carlo forecast [1]; [2] surveys the alternatives
  (projection, density truncation, ...).  It conditions the forecast on
  "never entered" - it does not model the object steering around.
* Polygon footprints use matplotlib's Path.contains_points, which
  implements Haines' "crossings-multiply" ray-crossing test [3]; the
  crossings test goes back to Shimrat [4].  Points exactly on an edge may
  be classed either way.
* Terrain uses bilinear interpolation on a regular grid (scipy
  RegularGridInterpolator, method 'linear') [5].
* Floor, ceiling, box and cylinder are direct inequality tests.
* Sampling.  predict_from_history.py tests positions after every
  integration sub-step (0.5 s by default), so an obstacle thinner than
  speed x sub-step (about 120 m at 240 m/s) can be stepped over.
  Swept-segment ("continuous") collision tests would remove this [6].

References
  [1] Shao, X., Huang, B., Lee, J. M. (2010). Constrained Bayesian state
      estimation - A comparative study and a new particle filter based
      approach. Journal of Process Control, 20(2), 143-157.
  [2] Simon, D. (2010). Kalman filtering with state constraints: a survey
      of linear and nonlinear algorithms. IET Control Theory &
      Applications, 4(8), 1303-1318.
  [3] Haines, E. (1994). Point in polygon strategies. In P. S. Heckbert
      (ed.), Graphics Gems IV, Academic Press, 24-46.
  [4] Shimrat, M. (1962). Algorithm 112: Position of point relative to
      polygon. Communications of the ACM, 5(8), 434.
  [5] Press, W. H., Teukolsky, S. A., Vetterling, W. T., Flannery, B. P.
      (2007). Numerical Recipes: The Art of Scientific Computing, 3rd ed.
      Cambridge University Press, Sec. 3.6.
  [6] Ericson, C. (2005). Real-Time Collision Detection. Morgan Kaufmann.
"""

import json

import numpy as np
from matplotlib.patches import Circle, Polygon, Rectangle
from matplotlib.path import Path
from scipy.interpolate import RegularGridInterpolator


class Obstacle:
    kind = "obstacle"
    name = None
    is_floor = False
    is_ceiling = False

    def inside(self, P):
        raise NotImplementedError

    def label(self):
        return self.name or self.kind

    def draw(self, ax, scale=1e-3, **kw):
        """Draw the horizontal footprint on an East-North map (scale m -> plot units)."""
        return None


class Floor(Obstacle):
    kind, is_floor = "floor", True

    def __init__(self, alt=0.0, name=None):
        self.alt, self.name = float(alt), name

    def inside(self, P):
        return P[:, 2] < self.alt

    def label(self):
        return self.name or f"below {self.alt:.0f} m"


class Ceiling(Obstacle):
    kind, is_ceiling = "ceiling", True

    def __init__(self, alt, name=None):
        self.alt, self.name = float(alt), name

    def inside(self, P):
        return P[:, 2] > self.alt

    def label(self):
        return self.name or f"above {self.alt:.0f} m"


class Box(Obstacle):
    kind = "box"

    def __init__(self, min, max, name=None):
        self.lo, self.hi = np.asarray(min, float), np.asarray(max, float)
        self.name = name

    def inside(self, P):
        return np.all((P >= self.lo) & (P <= self.hi), axis=1)

    def draw(self, ax, scale=1e-3, **kw):
        w, h = (self.hi[:2] - self.lo[:2]) * scale
        return ax.add_patch(Rectangle(self.lo[:2] * scale, w, h, **kw))


class Cylinder(Obstacle):
    kind = "cylinder"

    def __init__(self, center, radius, z_min=-np.inf, z_max=np.inf, name=None):
        self.c, self.r = np.asarray(center, float), float(radius)
        self.z_min, self.z_max, self.name = float(z_min), float(z_max), name

    def inside(self, P):
        d2 = np.sum((P[:, :2] - self.c) ** 2, axis=1)
        return (d2 <= self.r ** 2) & (P[:, 2] >= self.z_min) & (P[:, 2] <= self.z_max)

    def draw(self, ax, scale=1e-3, **kw):
        return ax.add_patch(Circle(self.c * scale, self.r * scale, **kw))


class Prism(Obstacle):
    """Polygon footprint extruded between z_min and z_max."""
    kind = "polygon"

    def __init__(self, vertices, z_min=-np.inf, z_max=np.inf, name=None):
        self.v = np.asarray(vertices, float)
        self.path = Path(self.v)
        self.z_min, self.z_max, self.name = float(z_min), float(z_max), name

    def inside(self, P):
        zin = (P[:, 2] >= self.z_min) & (P[:, 2] <= self.z_max)
        out = np.zeros(len(P), bool)
        if zin.any():
            out[zin] = self.path.contains_points(P[zin, :2])
        return out

    def draw(self, ax, scale=1e-3, **kw):
        return ax.add_patch(Polygon(self.v * scale, closed=True, **kw))


class Terrain(Obstacle):
    """Inside = below the terrain height (bilinear interpolation of a grid)."""
    kind = "terrain"

    def __init__(self, e, n, elev, name=None):
        self.e, self.n = np.asarray(e, float), np.asarray(n, float)
        self.elev = np.asarray(elev, float)
        if self.elev.shape != (len(self.n), len(self.e)):
            raise ValueError(f"terrain elev must be (len(n), len(e)) = "
                             f"{(len(self.n), len(self.e))}, got {self.elev.shape}")
        self.f = RegularGridInterpolator((self.n, self.e), self.elev, bounds_error=False,
                                         fill_value=-np.inf)
        self.name = name

    def height(self, E, N):
        return self.f(np.column_stack([N, E]))

    def inside(self, P):
        return P[:, 2] < self.height(P[:, 0], P[:, 1])

    def draw(self, ax, scale=1e-3, **kw):
        """Height contour lines (labelled in km), lowest 10% of relief omitted."""
        E, N = np.meshgrid(self.e * scale, self.n * scale)
        lo, hi = np.nanmin(self.elev), np.nanmax(self.elev)
        if hi <= lo:
            return None
        levels = np.linspace(lo + 0.1 * (hi - lo), hi, 6)[:-1]
        cs = ax.contour(E, N, self.elev, levels=levels, colors="#5d4037", linewidths=0.9,
                        alpha=0.7, zorder=1)
        ax.clabel(cs, fmt=lambda v: f"{v / 1e3:.1f} km", fontsize=7)
        return cs


def from_dict(d):
    d = dict(d)
    kind = d.pop("type").lower()
    name = d.pop("name", None)
    if kind == "floor":
        return Floor(d.get("alt", 0.0), name)
    if kind == "ceiling":
        return Ceiling(d["alt"], name)
    if kind == "box":
        return Box(d["min"], d["max"], name)
    if kind == "cylinder":
        return Cylinder(d["center"], d["radius"], d.get("z_min", -np.inf),
                        d.get("z_max", np.inf), name)
    if kind in ("polygon", "prism"):
        return Prism(d["vertices"], d.get("z_min", -np.inf), d.get("z_max", np.inf), name)
    if kind == "terrain":
        if "file" in d:
            g = np.load(d["file"])
            return Terrain(g["e"], g["n"], g["elev"], name)
        return Terrain(d["e"], d["n"], d["elev"], name)
    raise ValueError(f"unknown obstacle type '{kind}' "
                     "(floor, ceiling, box, cylinder, polygon, terrain)")


def load_obstacles(path):
    with open(path) as f:
        data = json.load(f)
    if isinstance(data, dict):
        data = data.get("obstacles", [data])
    return [from_dict(d) for d in data]


def inside_any(obstacles, P):
    hit = np.zeros(len(P), bool)
    for ob in obstacles:
        hit |= ob.inside(P)
    return hit
