"""
intent_mc.py
============
Long-horizon (minutes) trajectory prediction by Monte Carlo simulation of a
3-DOF point-mass aircraft flying under a set of INTENT hypotheses.
Dependencies: numpy and scipy only.

How it fits with imm_tracker.py
-------------------------------
    1. The IMM tracks the target and gives a state x (9,) and covariance P.
    2. HAND-OFF: particles are sampled from N(x, P) and converted to
       point-mass states (speed, flight-path angle, heading, bank).  Each
       particle is given an intent drawn from the prior (e.g. "fly to
       airfield B", "continue the current turn", "evasive maneuvering").
    3. INTENT INFERENCE (optional but recommended): start the hand-off a
       little in the past (e.g. 60 s) and let a particle filter assimilate
       the measurements since then.  Particles whose intent does not explain
       the observed track lose weight, so the intent probabilities update.
    4. PREDICT: fly every particle forward with its intent's guidance law
       and the aircraft's performance limits.  The result is a cloud of
       possible future positions (usually multi-modal: one lobe per intent).

Conventions
-----------
    position  : local ENU [m]  (x = East, y = North, h = Up)
    heading   : psi, from North, clockwise [rad]
    flight-path angle : gamma [rad];  bank : phi, + = right wing down [rad]

Unknown performance limits
--------------------------
Pass `classes=[PlatformClass(...), ...]` (see default_classes()) and every
particle gets its OWN capability parameters (max load factor, bank, excess
thrust, induced-drag factor, roll rate, climb rate, speed range) drawn from
its class's ranges.  Then:
  * an ObservedEnvelope (imm_tracker.py) truncates those ranges from below
    with what the target has demonstrated, and scores each class
    (e.g. a 6 g turn rules out a transport);
  * the particle filter re-weights capabilities with the intents, and
    Liu-West kernel shrinkage keeps the parameter cloud from collapsing
    after resampling.
Without `classes` the predictor behaves exactly as before (one fixed perf).

Point-mass equations of motion (flat earth, wind optional):
    Vdot     = (T - D)/m - g sin(gamma)
    gammadot = g/V (n cos(phi) - cos(gamma))
    psidot   = g n sin(phi) / (V cos(gamma))
with (T - D)/m limited by available thrust, reduced by induced drag
~ k (n^2 - 1), so hard turns bleed energy as they do in reality.

Methods and references
----------------------
Numbers in [] refer to the list at the end of this header.

Point-mass aircraft model.  The equations above are the standard 3-DOF
wind-axis point-mass equations over a flat earth [1, 2].  Bank angle is
recovered from a measured acceleration with the coordinated-turn relations
n sin(phi) = a_right/g and n cos(phi) = cos(gamma) + a_normal/g [1].  The
energy term follows the specific-excess-power view of performance
(Rutowski's energy method, Boyd's energy-maneuverability) [3, 4]: excess
acceleration (T - D)/m is capped by the available thrust and reduced by
induced drag, which for a parabolic drag polar grows with (n^2 - 1) [5].
This is the same force-based ("kinetic") approach as EUROCONTROL's BADA
[6], with generic, far simpler coefficients.  The autopilot laws
(heading -> bank, altitude -> climb rate -> flight-path angle, speed ->
thrust) are plain proportional loops chosen for robustness, not taken from
a particular reference.

Intent hypotheses.  Predicting with a discrete set of pilot goals, and
inferring the goal from the observed track, follows intent-based
trajectory prediction for air traffic [7, 8]; predicting by Monte Carlo
simulation of many possible futures follows [9].  Intents switch with
exponentially distributed holding times (mean `mean_duration`), i.e. a
continuous-time Markov jump process - the same idea that underlies
multiple-model filters such as the IMM [10].

Random manoeuvring.  The evasive bank command, the bank jitter and the slow
heading wander are Ornstein-Uhlenbeck (first-order Gauss-Markov) processes
[11], stepped with the exact discrete-time update
    x <- a x + sigma sqrt(1 - a^2) w,   a = exp(-dt / tau),  w ~ N(0, 1)
[12].  This is the correlated-manoeuvre idea of the Singer model, applied
to bank angle instead of acceleration [13, 14].

Particle filter (intent inference).  A bootstrap / sampling-importance-
resampling particle filter [15, 16, 17]: fly the particles with the model,
weight each by the Gaussian likelihood of the position measurement (R is
inflated by `model_sigma` to allow for model error - an engineering
choice), and resample when the effective sample size 1 / sum(w^2) drops
below N/2 [18, 19].  Resampling is systematic [20, 21], followed by small
"roughening" jitter so that copies of one particle separate again [15].

Unknown constant parameters (capabilities, wind).  These ride along in the
particles and are learned with Liu & West's kernel shrinkage [22]: after
resampling, each parameter is pulled toward its class mean by (1 - a) and
jittered with variance (1 - a^2) x class variance, which keeps the mean and
variance of the parameter cloud unchanged while refreshing its values.
Class probabilities are updated with Bayes' rule using a soft (normal-CDF)
likelihood that the class can do what the target has demonstrated; the
soft form and its tolerances are engineering choices.

Ensemble-Kalman correction.  After weighting, positions and velocities are
nudged toward the measurement with the stochastic (perturbed-observation)
ensemble Kalman filter update [23, 24], using the gain built from the
weighted cloud covariance.  Combining particle-filter weights with
ensemble-Kalman moves is related to the weighted EnKF [25] and the ensemble
Kalman particle filter [26]; the order used here (weight first, then move,
no weight correction for the move) is a pragmatic hybrid and does not carry
their exact sampling guarantees.  When the measurement falls outside the
cloud (chi-square test, 3 d.o.f., 99% [27]) the cloud spread is inflated
multiplicatively [28], with the innovation-based inflation estimate
    lambda^2 = (d'd - tr R) / tr(C)       (capped at 25)
of [29, 30, 31].

Forecast summaries.  Probability regions are highest-density regions
computed by the density-quantile method [32]: estimate the density with a
mixture of per-intent Gaussian kernel density estimates [33, 34] (scipy
gaussian_kde, Scott's-rule bandwidth), evaluate it at the particles, and
use the (1 - level) quantile of those values as the contour threshold.

References
  [1] Stevens, B. L., Lewis, F. L., Johnson, E. N. (2016). Aircraft Control
      and Simulation, 3rd ed. Wiley.
  [2] Miele, A. (1962). Flight Mechanics, Vol. 1: Theory of Flight Paths.
      Addison-Wesley.
  [3] Rutowski, E. S. (1954). Energy approach to the general aircraft
      performance problem. Journal of the Aeronautical Sciences, 21(3),
      187-195.
  [4] Boyd, J. R., Christie, T. P., Gibson, J. E. (1966).
      Energy-Maneuverability. Report APGC-TR-66-4, Air Proving Ground
      Center, Eglin AFB, FL.
  [5] Anderson, J. D. (1999). Aircraft Performance and Design. McGraw-Hill.
  [6] Nuic, A., Poles, D., Mouillet, V. (2010). BADA: An advanced aircraft
      performance model for present and future ATM systems. International
      Journal of Adaptive Control and Signal Processing, 24(10), 850-866.
  [7] Yepes, J. L., Hwang, I., Rotea, M. (2007). New algorithms for aircraft
      intent inference and trajectory prediction. Journal of Guidance,
      Control, and Dynamics, 30(2), 370-382.
  [8] Hwang, I., Seah, C. E. (2008). Intent-based probabilistic conflict
      detection for the next generation air transportation system.
      Proceedings of the IEEE, 96(12), 2040-2059.
  [9] Prandini, M., Hu, J., Lygeros, J., Sastry, S. (2000). A probabilistic
      approach to aircraft conflict detection. IEEE Transactions on
      Intelligent Transportation Systems, 1(4), 199-220.
  [10] Blom, H. A. P., Bar-Shalom, Y. (1988). The interacting multiple model
      algorithm for systems with Markovian switching coefficients. IEEE
      Transactions on Automatic Control, 33(8), 780-783.
  [11] Uhlenbeck, G. E., Ornstein, L. S. (1930). On the theory of the
      Brownian motion. Physical Review, 36(5), 823-841.
  [12] Gillespie, D. T. (1996). Exact numerical simulation of the
      Ornstein-Uhlenbeck process and its integral. Physical Review E,
      54(2), 2084-2091.
  [13] Singer, R. A. (1970). Estimating optimal tracking filter performance
      for manned maneuvering targets. IEEE Transactions on Aerospace and
      Electronic Systems, AES-6(4), 473-483.
  [14] Li, X. R., Jilkov, V. P. (2003). Survey of maneuvering target
      tracking. Part I: Dynamic models. IEEE Transactions on Aerospace and
      Electronic Systems, 39(4), 1333-1364.
  [15] Gordon, N. J., Salmond, D. J., Smith, A. F. M. (1993). Novel approach
      to nonlinear/non-Gaussian Bayesian state estimation. IEE Proceedings
      F, 140(2), 107-113.
  [16] Arulampalam, M. S., Maskell, S., Gordon, N., Clapp, T. (2002). A
      tutorial on particle filters for online nonlinear/non-Gaussian
      Bayesian tracking. IEEE Transactions on Signal Processing, 50(2),
      174-188.
  [17] Doucet, A., de Freitas, N., Gordon, N. (eds.) (2001). Sequential
      Monte Carlo Methods in Practice. Springer.
  [18] Kong, A., Liu, J. S., Wong, W. H. (1994). Sequential imputations and
      Bayesian missing data problems. Journal of the American Statistical
      Association, 89(425), 278-288.
  [19] Liu, J. S., Chen, R. (1998). Sequential Monte Carlo methods for
      dynamic systems. Journal of the American Statistical Association,
      93(443), 1032-1044.
  [20] Kitagawa, G. (1996). Monte Carlo filter and smoother for non-Gaussian
      nonlinear state space models. Journal of Computational and Graphical
      Statistics, 5(1), 1-25.
  [21] Douc, R., Cappe, O., Moulines, E. (2005). Comparison of resampling
      schemes for particle filtering. Proc. 4th International Symposium on
      Image and Signal Processing and Analysis (ISPA 2005), 64-69.
  [22] Liu, J., West, M. (2001). Combined parameter and state estimation in
      simulation-based filtering. In [17], 197-223.
  [23] Evensen, G. (1994). Sequential data assimilation with a nonlinear
      quasi-geostrophic model using Monte Carlo methods to forecast error
      statistics. Journal of Geophysical Research, 99(C5), 10143-10162.
  [24] Burgers, G., van Leeuwen, P. J., Evensen, G. (1998). Analysis scheme
      in the ensemble Kalman filter. Monthly Weather Review, 126(6),
      1719-1724.
  [25] Papadakis, N., Memin, E., Cuzol, A., Gengembre, N. (2010). Data
      assimilation with the weighted ensemble Kalman filter. Tellus A,
      62(5), 673-697.
  [26] Frei, M., Kunsch, H. R. (2013). Bridging the ensemble Kalman and
      particle filters. Biometrika, 100(4), 781-800.
  [27] Bar-Shalom, Y., Li, X. R., Kirubarajan, T. (2001). Estimation with
      Applications to Tracking and Navigation. Wiley.
  [28] Anderson, J. L., Anderson, S. L. (1999). A Monte Carlo
      implementation of the nonlinear filtering problem to produce ensemble
      assimilations and forecasts. Monthly Weather Review, 127(12),
      2741-2758.
  [29] Wang, X., Bishop, C. H. (2003). A comparison of breeding and ensemble
      transform Kalman filter ensemble forecast schemes. Journal of the
      Atmospheric Sciences, 60(9), 1140-1158.
  [30] Anderson, J. L. (2007). An adaptive covariance inflation error
      correction algorithm for ensemble filters. Tellus A, 59(2), 210-224.
  [31] Li, H., Kalnay, E., Miyoshi, T. (2009). Simultaneous estimation of
      covariance inflation and observation errors within an ensemble Kalman
      filter. Quarterly Journal of the Royal Meteorological Society,
      135(639), 523-533.
  [32] Hyndman, R. J. (1996). Computing and graphing highest density
      regions. The American Statistician, 50(2), 120-126.
  [33] Silverman, B. W. (1986). Density Estimation for Statistics and Data
      Analysis. Chapman & Hall.
  [34] Scott, D. W. (1992). Multivariate Density Estimation: Theory,
      Practice, and Visualization. Wiley.
"""

import copy
from dataclasses import dataclass, replace

import numpy as np
from scipy.special import logsumexp
from scipy.stats import gaussian_kde, norm

G = 9.80665


def wrap_pi(a):
    """Wrap an angle (or array) to [-pi, pi)."""
    return (a + np.pi) % (2.0 * np.pi) - np.pi


# ---------------------------------------------------------------------------
# Aircraft performance and the point-mass step
# ---------------------------------------------------------------------------
@dataclass
class AircraftPerformance:
    """Performance limits + simple autopilot gains.  Defaults are roughly a
    fighter-class aircraft at medium altitude; replace with your own data."""
    n_max: float = 6.0                 # max load factor [g]
    n_min: float = -1.5
    phi_max_deg: float = 85.0          # absolute bank clamp (per-particle limits bind first)
    roll_rate_max_deg: float = 90.0    # [deg/s]
    tau_roll: float = 0.7              # bank-response time constant [s]
    gamma_max_deg: float = 30.0        # max |flight-path angle|
    climb_rate_max: float = 60.0       # max commanded |climb rate| [m/s]
    a_thrust_max: float = 6.0          # max excess (T-D)/m at 1 g [m/s^2]
    a_brake_max: float = 6.0           # max deceleration (idle + speedbrake)
    k_induced: float = 0.25            # extra decel per (n^2 - 1) [m/s^2]
    V_min: float = 110.0               # [m/s]
    V_max: float = 420.0
    K_psi: float = 2.0                 # bank command per heading error [-]
    K_h: float = 0.05                  # climb rate per altitude error [1/s]
    K_gamma: float = 1.0               # [1/s]
    K_V: float = 0.1                   # [1/s]


STATE_KEYS = ("x", "y", "h", "V", "gam", "psi", "phi")


def point_mass_step(S, phi_cmd, h_cmd, V_cmd, phi_lim, perf, dt, wind=(0.0, 0.0, 0.0)):
    """Advance point-mass states in place by dt.  Works on arrays of any
    length (one entry per particle).

    S        : dict with arrays x, y, h, V, gam, psi, phi
    phi_cmd  : commanded bank [rad]
    h_cmd    : commanded altitude [m]
    V_cmd    : commanded true airspeed [m/s]
    phi_lim  : per-particle bank limit [rad] (pilot aggressiveness)
    """
    p = perf
    V, gam, psi, phi, h = S["V"], S["gam"], S["psi"], S["phi"], S["h"]

    # --- lateral: first-order roll response with roll-rate limit
    phi_c = np.clip(phi_cmd, -phi_lim, phi_lim)
    p_max = np.radians(p.roll_rate_max_deg)
    phi_new = phi + np.clip((phi_c - phi) / p.tau_roll, -p_max, p_max) * dt
    phi_new = np.clip(phi_new, -np.radians(p.phi_max_deg), np.radians(p.phi_max_deg))

    # --- vertical: altitude -> climb rate -> flight-path angle -> load factor
    climb_cmd = np.clip(p.K_h * (h_cmd - h), -p.climb_rate_max, p.climb_rate_max)
    sg_max = np.sin(np.radians(p.gamma_max_deg))
    gam_cmd = np.arcsin(np.clip(climb_cmd / V, -sg_max, sg_max))
    cphi = np.cos(phi_new)
    n_req = (np.cos(gam) + V / G * p.K_gamma * (gam_cmd - gam)) / np.maximum(cphi, 0.05)
    n = np.clip(n_req, p.n_min, p.n_max)

    gam_dot = G / V * (n * cphi - np.cos(gam))
    psi_dot = G * n * np.sin(phi_new) / (V * np.cos(gam))

    # --- energy: excess thrust limited, induced drag grows with n^2
    a_avail = p.a_thrust_max - p.k_induced * (n ** 2 - 1.0)
    a_x = np.minimum(np.maximum(p.K_V * (V_cmd - V) + G * np.sin(gam), -p.a_brake_max), a_avail)
    V_dot = a_x - G * np.sin(gam)

    # --- integrate (midpoint for the kinematics)
    V_new = np.clip(V + V_dot * dt, p.V_min, p.V_max)
    gam_new = np.clip(gam + gam_dot * dt, -1.4, 1.4)
    psi_new = psi + psi_dot * dt
    Vm, gm, pm = 0.5 * (V + V_new), 0.5 * (gam + gam_new), 0.5 * (psi + psi_new)
    S["x"] = S["x"] + (Vm * np.cos(gm) * np.sin(pm) + wind[0]) * dt
    S["y"] = S["y"] + (Vm * np.cos(gm) * np.cos(pm) + wind[1]) * dt
    S["h"] = S["h"] + (Vm * np.sin(gm) + wind[2]) * dt
    S["V"], S["gam"], S["psi"], S["phi"] = V_new, gam_new, wrap_pi(psi_new), phi_new


def state_from_cartesian(p, v, a):
    """Convert ENU position/velocity/acceleration arrays (N,3) to point-mass
    states.  Bank is recovered from the acceleration perpendicular to v:
        n sin(phi) = a_right / g,   n cos(phi) = cos(gamma) + a_normal / g
    """
    V = np.maximum(np.linalg.norm(v, axis=1), 1.0)
    psi = np.arctan2(v[:, 0], v[:, 1])
    gam = np.arcsin(np.clip(v[:, 2] / V, -1.0, 1.0))
    r_hat = np.stack([np.cos(psi), -np.sin(psi), np.zeros_like(psi)], axis=1)
    n_hat = np.stack([-np.sin(gam) * np.sin(psi), -np.sin(gam) * np.cos(psi), np.cos(gam)], axis=1)
    a_r = np.sum(a * r_hat, axis=1)
    a_n = np.sum(a * n_hat, axis=1)
    phi = np.arctan2(a_r / G, np.cos(gam) + a_n / G)
    return {"x": p[:, 0].copy(), "y": p[:, 1].copy(), "h": p[:, 2].copy(),
            "V": V, "gam": gam, "psi": psi, "phi": phi}


# ---------------------------------------------------------------------------
# Capability priors for when the limits are NOT known
# ---------------------------------------------------------------------------
THETA_KEYS = ("n_max", "bank", "a_thrust_max", "k_induced", "roll_rate_max_deg",
              "climb_rate_max", "V_min", "V_max")
_PERF_KEYS = tuple(k for k in THETA_KEYS if k != "bank")


@dataclass
class PlatformClass:
    """Prior capability ranges (low, high) for one class of object.  Each
    particle of this class draws its own values uniformly from the ranges.

    n_max          max load factor [g]
    bank           (deg) bank angle the pilot/autopilot is willing to use
    a_thrust_max   max excess (T-D)/m at 1 g [m/s^2]
    k_induced      extra deceleration per (n^2 - 1) [m/s^2]
    roll_rate_max_deg, climb_rate_max [m/s], V_min, V_max [m/s]
    """
    name: str
    prior: float = 1.0
    n_max: tuple = (5.0, 9.0)
    bank: tuple = (30.0, 80.0)
    a_thrust_max: tuple = (3.0, 10.0)
    k_induced: tuple = (0.10, 0.40)
    roll_rate_max_deg: tuple = (60.0, 240.0)
    climb_rate_max: tuple = (40.0, 150.0)
    V_min: tuple = (90.0, 150.0)
    V_max: tuple = (350.0, 600.0)

    def range(self, key):
        lo, hi = getattr(self, key)
        if key == "bank":
            lo, hi = np.radians(lo), np.radians(hi)
        return float(lo), float(hi)


def default_classes():
    """Generic, deliberately broad class priors (placeholders - replace with
    your own data for the platforms you care about)."""
    return [
        PlatformClass("transport", prior=0.35, n_max=(2.0, 3.0), bank=(15.0, 35.0),
                      a_thrust_max=(0.5, 3.0), k_induced=(0.05, 0.30),
                      roll_rate_max_deg=(5.0, 20.0), climb_rate_max=(8.0, 25.0),
                      V_min=(70.0, 140.0), V_max=(230.0, 290.0)),
        PlatformClass("fighter", prior=0.35, n_max=(5.0, 9.0), bank=(30.0, 85.0),
                      a_thrust_max=(3.0, 10.0), k_induced=(0.10, 0.40),
                      roll_rate_max_deg=(60.0, 240.0), climb_rate_max=(40.0, 150.0),
                      V_min=(90.0, 150.0), V_max=(350.0, 600.0)),
        PlatformClass("UAV", prior=0.30, n_max=(1.5, 4.0), bank=(15.0, 50.0),
                      a_thrust_max=(0.3, 2.5), k_induced=(0.05, 0.40),
                      roll_rate_max_deg=(10.0, 60.0), climb_rate_max=(3.0, 15.0),
                      V_min=(20.0, 45.0), V_max=(60.0, 130.0)),
    ]


def class_log_evidence(cls, env, tol=None):
    """log P(observed envelope | class): soft check that the class can do
    everything the target has demonstrated (normal-CDF softening by tol)."""
    tol = tol or {"n": 0.3, "bank": np.radians(3.0), "V": 10.0, "a": 0.5}
    if env is None:
        return 0.0
    ll = norm.logcdf((cls.range("n_max")[1] - env.n_demo) / tol["n"])
    ll += norm.logcdf((cls.range("bank")[1] - env.bank_demo) / tol["bank"])
    ll += norm.logcdf((cls.range("V_max")[1] - env.V_hi_demo) / tol["V"])
    if np.isfinite(env.V_lo_demo):
        ll += norm.logcdf((env.V_lo_demo - cls.range("V_min")[0]) / tol["V"])
    req = float(env.required_thrust(cls.range("k_induced")[0]))
    if np.isfinite(req):
        ll += norm.logcdf((cls.range("a_thrust_max")[1] - req) / tol["a"])
    return float(ll)


# ---------------------------------------------------------------------------
# Intent hypotheses
# ---------------------------------------------------------------------------
@dataclass
class Intent:
    """One hypothesis about what the target is trying to do.

    kind:
      'straight'      : roll out and hold current heading / altitude / speed
      'continue_turn' : hold current bank for a random time, then roll out
      'evasive'       : random bank reversals (OU process on bank command)
      'fly_to'        : turn toward `waypoint` (E, N) [m], go to `altitude`,
                        orbit once within `arrive_radius`
    altitude / speed : optional targets [m], [m/s] (None = hold current)
    prior            : prior probability (normalized internally)
    mean_duration    : how long, on average, the target sticks with this
                       intent before switching to another (drawn from the
                       priors).  E.g. evasive ~30 s, straight ~2 min,
                       fly_to = inf (committed).  Used both when inferring
                       intent and when predicting, so the forecast includes
                       plan changes.
    """
    name: str
    kind: str
    prior: float = 1.0
    waypoint: tuple = None
    altitude: float = None
    speed: float = None
    turn_duration: tuple = (0.0, 30.0)     # continue_turn: uniform range [s]
    evasive_tau: float = 6.0               # evasive: bank correlation time [s]
    evasive_bank_deg: float = 45.0         # evasive: RMS bank command [deg]
    arrive_radius: float = 3000.0          # fly_to [m]
    orbit_bank_deg: float = 30.0           # fly_to: bank used to orbit on arrival
    mean_duration: float = np.inf          # average time [s] before the target abandons
                                           # this intent for another one (inf = committed)

    def __post_init__(self):
        kinds = ("straight", "continue_turn", "evasive", "fly_to")
        if self.kind not in kinds:
            raise ValueError(f"kind must be one of {kinds}")
        if self.kind == "fly_to" and self.waypoint is None:
            raise ValueError("fly_to intent needs a waypoint")


# ---------------------------------------------------------------------------
# Monte Carlo predictor / particle filter
# ---------------------------------------------------------------------------
class IntentMonteCarlo:
    """Particle-based long-horizon predictor with intent hypotheses.

    intents          : list of Intent
    perf             : AircraftPerformance
    n_particles      : number of Monte Carlo samples
    bank_limit_deg   : range of per-particle bank limits (pilot aggressiveness)
    substep          : integration step [s]
    wind_sigma       : std of the unknown (constant) wind per particle [m/s];
                       None/0 if wind is known and passed to predict()
    speed_jitter     : relative std of each particle's commanded speed
    bank_jitter_deg, bank_jitter_tau :
                       small, fast random bank perturbation on every particle
                       (keeps the cloud diverse enough to follow maneuver
                       onsets the intents don't predict)
    heading_wander_deg, heading_wander_tau :
                       slow random drift of the held heading for 'straight'
                       flight (pilots/autopilots rarely hold a heading for
                       minutes) - OU process, RMS [deg] and time constant [s]
    classes          : list of PlatformClass for UNKNOWN limits (None = use
                       `perf` as known, with bank limits from bank_limit_deg)
    liu_west_a       : Liu-West shrinkage factor (0.95-0.99) applied to the
                       capability parameters after each resampling; default
                       0.98 when classes are given, off otherwise
    """

    _MEM = ("intent", "psi_hold", "h_hold", "V_hold", "phi_hold",
            "turn_end", "phi_ou", "arrived", "wE", "wN", "psi_wander", "V_scale", "phi_jit", "cls")

    def __init__(self, intents, perf=None, n_particles=3000,
                 bank_limit_deg=(25.0, 75.0), substep=0.5, seed=None,
                 wind_sigma=8.0, speed_jitter=0.03,
                 heading_wander_deg=10.0, heading_wander_tau=60.0,
                 bank_jitter_deg=5.0, bank_jitter_tau=2.0,
                 classes=None, liu_west_a=None):
        self.intents = list(intents)
        self.perf = perf or AircraftPerformance()
        self.N = int(n_particles)
        self.bank_limit = np.radians(bank_limit_deg)
        if classes is None:                      # known performance: one fixed "class"
            p = self.perf
            fixed = {k: (getattr(p, k), getattr(p, k)) for k in _PERF_KEYS}
            classes = [PlatformClass("assumed", bank=tuple(bank_limit_deg), **fixed)]
            self.lw_a = liu_west_a
        else:
            self.lw_a = 0.98 if liu_west_a is None else liu_west_a
        self.classes = list(classes)
        cp = np.array([c.prior for c in self.classes], float)
        self.class_prior = cp / cp.sum()
        self.evasive_bank_rms = None
        self.prior_exceeded, self.prior_at_edge = [], []
        self.substep = substep
        self.wind_sigma = wind_sigma or 0.0
        self.speed_jitter = speed_jitter
        self.wander_sig = np.radians(heading_wander_deg)
        self.wander_tau = heading_wander_tau
        self.jit_sig = np.radians(bank_jitter_deg)
        self.jit_tau = bank_jitter_tau
        self.rng = np.random.default_rng(seed)
        pri = np.array([it.prior for it in self.intents], float)
        self.prior = pri / pri.sum()
        self.t = 0.0
        self.S = None

    @property
    def names(self):
        return [it.name for it in self.intents]

    # -- hand-off from the IMM ---------------------------------------------
    def initialize_from_imm(self, x, P, t0=0.0, envelope=None, usage=None):
        """Sample particles from the IMM estimate N(x, P) (9-state:
        position, velocity, acceleration in ENU).

        envelope : imm_tracker.ObservedEnvelope - demonstrated capability.
                   Class probabilities are multiplied by how consistent each
                   class is with it, and each particle's capability is drawn
                   no lower than what has been demonstrated (even if that
                   is outside every class's range - evidence beats prior).
        usage    : imm_tracker.ManeuverLevelEstimator - learned maneuver
                   level; sets the RMS bank of 'evasive' intents.
        """
        X = self.rng.multivariate_normal(x, P + 1e-9 * np.eye(len(x)), self.N,
                                         method="cholesky")
        # unknown wind: the IMM measures GROUND velocity; airspeed = ground - wind
        self.wE = self.wind_sigma * self.rng.standard_normal(self.N)
        self.wN = self.wind_sigma * self.rng.standard_normal(self.N)
        v_air = X[:, 3:6] - np.stack([self.wE, self.wN, np.zeros(self.N)], axis=1)
        self.S = state_from_cartesian(X[:, 0:3], v_air, X[:, 6:9])
        self.V_scale = 1.0 + self.speed_jitter * self.rng.standard_normal(self.N)
        self.psi_wander = np.zeros(self.N)
        self.phi_jit = np.zeros(self.N)
        self.t = float(t0)
        self.intent = self.rng.choice(len(self.intents), size=self.N, p=self.prior)
        self._init_capability(envelope)
        if usage is not None:
            self.evasive_bank_rms = float(np.clip(np.arctan(usage.sigma_lat / G),
                                                  np.radians(10.0), np.radians(80.0)))
        for name in ("psi_hold", "h_hold", "V_hold", "phi_hold", "turn_end", "phi_ou"):
            setattr(self, name, np.zeros(self.N))
        self.arrived = np.zeros(self.N, bool)
        self._enter_intent(np.arange(self.N))
        self.logw = np.full(self.N, -np.log(self.N))

    def _init_capability(self, env):
        """Draw per-particle capability parameters (truncated by the
        observed envelope) and class labels."""
        nc = len(self.classes)
        logp = np.log(self.class_prior)
        if env is not None:
            logp = logp + np.array([class_log_evidence(c, env) for c in self.classes])
        self.class_post0 = np.exp(logp - logsumexp(logp))
        self.cls = (np.zeros(self.N, int) if nc == 1
                    else self.rng.choice(nc, size=self.N, p=self.class_post0))

        # lower bounds (capability must be AT LEAST what was demonstrated)
        lb = {k: -np.inf for k in THETA_KEYS}
        ub = {k: np.inf for k in THETA_KEYS}
        if env is not None:
            lb["n_max"], lb["bank"], lb["V_max"] = env.n_demo, env.bank_demo, env.V_hi_demo
            ub["V_min"] = env.V_lo_demo
        self.theta = {k: np.empty(self.N) for k in THETA_KEYS}
        for c, pc in enumerate(self.classes):
            m = np.flatnonzero(self.cls == c)
            if not m.size:
                continue
            for k in THETA_KEYS:
                lo, hi = pc.range(k)
                if lb[k] > hi:                      # evidence beyond this class's prior:
                    hi = lb[k] * 1.25               # allow 25% headroom above demonstrated
                lo, hi = max(lo, lb[k]), max(hi, lb[k])
                lo, hi = min(lo, ub[k]), min(hi, ub[k])
                self.theta[k][m] = (np.full(m.size, lo) if hi <= lo
                                    else self.rng.uniform(lo, hi, size=m.size))
        if env is not None:                         # energy: a_thrust >= a_x + k (n^2 - 1)
            req = env.required_thrust(self.theta["k_induced"])
            self.theta["a_thrust_max"] = np.maximum(self.theta["a_thrust_max"], req)
        self._lb, self._ub, self._env = lb, ub, env

        # report demonstrated capability that no class allows, or that sits
        # near the top of the prior (then the prior may be what limits the
        # forecast - and the demonstrated value is only a lower bound)
        self.prior_exceeded, self.prior_at_edge = [], []
        if env is not None:
            for key, val, label in (("n_max", env.n_demo, "load factor"),
                                    ("bank", env.bank_demo, "bank"),
                                    ("V_max", env.V_hi_demo, "speed")):
                top = max(c.range(key)[1] for c in self.classes)
                if val > top:
                    self.prior_exceeded.append(label)
                elif val > 0.9 * top and key != "bank":
                    self.prior_at_edge.append(label)

    def _enforce_bounds(self):
        th = self.theta
        for k in THETA_KEYS:
            th[k] = np.clip(th[k], self._lb[k], self._ub[k])
        th["V_min"] = np.minimum(th["V_min"], th["V_max"] - 20.0)
        th["k_induced"] = np.maximum(th["k_induced"], 0.0)
        th["n_max"] = np.maximum(th["n_max"], 1.05)
        if self._env is not None:
            th["a_thrust_max"] = np.maximum(th["a_thrust_max"],
                                            self._env.required_thrust(th["k_induced"]))

    def _liu_west(self):
        """Liu & West (2001) kernel shrinkage: pull each particle's parameters
        toward its class mean by (1 - a) and add jitter with variance
        (1 - a^2) x class variance.  Keeps the parameter spread (mean and
        variance preserved) while refreshing values after resampling.
        Positive parameters are handled in log space."""
        a = self.lw_a
        h = np.sqrt(1.0 - a * a)
        for c in range(len(self.classes)):
            m = np.flatnonzero(self.cls == c)
            if m.size < 2:
                continue
            for k in THETA_KEYS:
                v = self.theta[k][m]
                lo, hi = self.classes[c].range(k)
                lin = k == "k_induced"                  # can be ~0: work in linear space
                width = (hi - lo) if lin else np.log(max(hi, 1e-6) / max(lo, 1e-6))
                if width <= 0:                          # parameter known exactly
                    continue
                u = v if lin else np.log(np.maximum(v, 1e-6))
                # floor the spread at 5% of the prior width so a collapsed
                # cloud (all weight on one particle) can still move
                sd = max(u.std(), 0.05 * width)
                u = a * u + (1 - a) * u.mean() + h * sd * self.rng.standard_normal(m.size)
                self.theta[k][m] = u if lin else np.exp(u)
        self._enforce_bounds()

    def _perf_view(self):
        """AircraftPerformance whose capability fields are per-particle arrays."""
        return replace(self.perf, **{k: self.theta[k] for k in _PERF_KEYS})

    def _enter_intent(self, idx):
        """Reset the per-particle memory of particles idx for their intent."""
        S = self.S
        self.psi_hold[idx] = S["psi"][idx]
        self.h_hold[idx] = S["h"][idx]
        self.V_hold[idx] = S["V"][idx] * self.V_scale[idx]
        self.psi_wander[idx] = 0.0
        self.phi_hold[idx] = S["phi"][idx]
        self.phi_ou[idx] = S["phi"][idx]
        self.arrived[idx] = False
        for j, it in enumerate(self.intents):
            m = idx[self.intent[idx] == j]
            if it.kind == "continue_turn" and m.size:
                self.turn_end[m] = self.t + self.rng.uniform(*it.turn_duration, size=m.size)

    # -- guidance: intent -> commands ----------------------------------------
    def _commands(self, dt):
        S, p = self.S, self.perf
        h_cmd = self.h_hold.copy()
        V_cmd = self.V_hold.copy()
        a = np.exp(-dt / self.wander_tau)                          # slow heading drift
        self.psi_wander = (a * self.psi_wander + self.wander_sig * np.sqrt(1 - a * a)
                           * self.rng.standard_normal(self.N))
        phi_cmd = p.K_psi * wrap_pi(self.psi_hold + self.psi_wander - S["psi"])  # heading hold

        for j, it in enumerate(self.intents):
            m = self.intent == j
            if not m.any():
                continue
            if it.altitude is not None:
                h_cmd[m] = it.altitude
            if it.speed is not None:
                V_cmd[m] = it.speed

            if it.kind == "continue_turn":
                turning = m & (self.t < self.turn_end)
                phi_cmd[turning] = self.phi_hold[turning]
                self.psi_hold[turning] = S["psi"][turning]          # roll out on this heading

            elif it.kind == "evasive":
                a = np.exp(-dt / it.evasive_tau)
                sig = (self.evasive_bank_rms if self.evasive_bank_rms is not None
                       else np.radians(it.evasive_bank_deg))
                self.phi_ou[m] = (a * self.phi_ou[m]
                                  + sig * np.sqrt(1 - a * a) * self.rng.standard_normal(m.sum()))
                phi_cmd[m] = self.phi_ou[m]

            elif it.kind == "fly_to":
                dE = it.waypoint[0] - S["x"][m]
                dN = it.waypoint[1] - S["y"][m]
                self.arrived[m] |= np.hypot(dE, dN) < it.arrive_radius
                brg = np.arctan2(dE, dN)
                cmd = p.K_psi * wrap_pi(brg - S["psi"][m])
                cmd[self.arrived[m]] = np.radians(it.orbit_bank_deg)
                phi_cmd[m] = cmd

        b = np.exp(-dt / self.jit_tau)                              # bank jitter
        self.phi_jit = (b * self.phi_jit + self.jit_sig * np.sqrt(1 - b * b)
                        * self.rng.standard_normal(self.N))
        return phi_cmd + self.phi_jit, h_cmd, V_cmd

    # -- propagation ---------------------------------------------------------
    def _switch_intents(self, dt):
        """Semi-Markov intent changes: a particle leaves intent j with
        probability 1 - exp(-dt / mean_duration_j) and picks a new intent
        from the priors (excluding the one it is leaving)."""
        dur = np.array([it.mean_duration for it in self.intents])[self.intent]
        sw = np.flatnonzero(self.rng.random(self.N) < -np.expm1(-dt / dur))
        if not sw.size:
            return
        m = len(self.intents)
        for i in sw:
            p = self.prior.copy()
            p[self.intent[i]] = 0.0
            self.intent[i] = self.rng.choice(m, p=p / p.sum())
        self._enter_intent(sw)

    def propagate(self, dt, allow_switching=True, wind=None):
        """Fly all particles forward by dt.  wind = known wind (E, N, U)
        [m/s]; if None each particle uses its own sampled unknown wind."""
        if allow_switching:
            self._switch_intents(dt)
        if wind is None:
            wind = (self.wE, self.wN, 0.0)
        n_sub = max(1, int(round(dt / self.substep)))
        h = dt / n_sub
        perf = self._perf_view()
        for _ in range(n_sub):
            phi_cmd, h_cmd, V_cmd = self._commands(h)
            point_mass_step(self.S, phi_cmd, h_cmd, V_cmd, self.theta["bank"], perf, h, wind)
            self.t += h

    # -- particle-filter measurement update (intent inference) ----------------
    def assimilate(self, z, R, dt, model_sigma=30.0, ensemble_correction=True):
        """Propagate dt, then use a position measurement z.

        1. Intent inference: weight each particle by how well its prediction
           matches z (R inflated by model_sigma, since the point-mass model
           and intents are only approximations).  Resample when needed.
        2. Kinematic correction (ensemble_correction=True): nudge every
           particle's position and velocity toward z with an ensemble-Kalman
           gain built from the cloud's own spread.  Step 1 has already
           scored the intents, so this does not bias the inference; it only
           stops the cloud drifting off the track when the real target
           maneuvers in ways no intent model captures exactly
           (a particle-filter / ensemble-Kalman hybrid).
        """
        self.propagate(dt)
        Reff = np.asarray(R) + model_sigma ** 2 * np.eye(3)
        Rinv = np.linalg.inv(Reff)
        d = self.positions() - z
        self.logw += -0.5 * np.einsum("ij,jk,ik->i", d, Rinv, d)
        self.logw -= logsumexp(self.logw)
        if self.ess() < 0.5 * self.N:
            self._resample()
        if ensemble_correction:
            self._ensemble_correct(z, Reff)

    def _ground_velocity(self):
        S = self.S
        cg = np.cos(S["gam"])
        return np.stack([S["V"] * cg * np.sin(S["psi"]) + self.wE,
                         S["V"] * cg * np.cos(S["psi"]) + self.wN,
                         S["V"] * np.sin(S["gam"])], axis=1)

    def _ensemble_correct(self, z, Reff, max_inflation=25.0):
        """Stochastic ensemble-Kalman update of position and ground velocity,
        with adaptive multiplicative inflation: if the measurement misses the
        cloud by more than the cloud's own spread (+ R) can explain (chi-square
        test at the 99% level), the
        cloud has collapsed onto a wrong solution (model mismatch, e.g. the
        real aircraft bleeds less energy in a hard turn than the particles
        assume).  The spread is then scaled up so the correction - and the
        next resampling - have room to work."""
        w = np.exp(self.logw)
        X = np.hstack([self.positions(), self._ground_velocity()])      # (N, 6)
        mu = w @ X
        D = X - mu
        C = (w[:, None] * D).T @ D                                      # ensemble covariance
        d = z - mu[:3]
        lam2 = (d @ d - np.trace(Reff)) / max(np.trace(C[:3, :3]), 1e-6)
        miss = d @ np.linalg.solve(C[:3, :3] + Reff, d)          # chi-square, 3 dof
        if miss > 11.34 and lam2 > 1.0:                           # only on a 99%-level miss
            lam2 = min(lam2, max_inflation)
            X = mu + np.sqrt(lam2) * D
            C = lam2 * C
        K = np.linalg.solve(C[:3, :3] + Reff, C[:3, :]).T               # (6, 3) gain
        zp = z + self.rng.multivariate_normal(np.zeros(3), Reff, self.N)
        X = X + (zp - X[:, :3]) @ K.T
        S = self.S
        S["x"], S["y"], S["h"] = X[:, 0], X[:, 1], X[:, 2]
        va = X[:, 3:6] - np.stack([self.wE, self.wN, np.zeros(self.N)], axis=1)
        S["V"] = np.clip(np.linalg.norm(va, axis=1), self.theta["V_min"], self.theta["V_max"])
        S["psi"] = np.arctan2(va[:, 0], va[:, 1])
        S["gam"] = np.arcsin(np.clip(va[:, 2] / S["V"], -1.0, 1.0))

    def ess(self):
        return 1.0 / np.sum(np.exp(2.0 * self.logw))

    def _resample(self):
        """Systematic resampling followed by small 'roughening' jitter."""
        w = np.exp(self.logw)
        c = np.cumsum(w)
        c[-1] = 1.0
        u = (self.rng.random() + np.arange(self.N)) / self.N
        idx = np.searchsorted(c, u)
        for k in STATE_KEYS:
            self.S[k] = self.S[k][idx]
        for k in self._MEM:
            setattr(self, k, getattr(self, k)[idx])
        for k in THETA_KEYS:
            self.theta[k] = self.theta[k][idx]
        r = self.rng.standard_normal
        self.S["x"] += 5.0 * r(self.N)
        self.S["y"] += 5.0 * r(self.N)
        self.S["h"] += 3.0 * r(self.N)
        self.S["V"] += 1.0 * r(self.N)
        self.S["psi"] = wrap_pi(self.S["psi"] + np.radians(0.5) * r(self.N))
        self.S["gam"] += np.radians(0.2) * r(self.N)
        self.S["phi"] += np.radians(2.0) * r(self.N)
        self.wE += 0.5 * r(self.N)
        self.wN += 0.5 * r(self.N)
        self.logw = np.full(self.N, -np.log(self.N))
        if self.lw_a is not None:
            self._liu_west()

    # -- outputs --------------------------------------------------------------
    def positions(self):
        return np.stack([self.S["x"], self.S["y"], self.S["h"]], axis=1)

    def intent_probabilities(self):
        w = np.exp(self.logw)
        return np.array([w[self.intent == j].sum() for j in range(len(self.intents))])

    @property
    def class_names(self):
        return [c.name for c in self.classes]

    def class_probabilities(self):
        w = np.exp(self.logw)
        return np.array([w[self.cls == c].sum() for c in range(len(self.classes))])

    def capability_summary(self, q=(0.05, 0.5, 0.95)):
        """Weighted quantiles of each capability parameter across particles
        (bank in degrees)."""
        w = np.exp(self.logw)
        out = {}
        for k in THETA_KEYS:
            v = np.degrees(self.theta[k]) if k == "bank" else self.theta[k]
            o = np.argsort(v)
            cw = np.cumsum(w[o])
            out[k] = tuple(float(v[o][np.searchsorted(cw, qq * cw[-1])]) for qq in q)
        return out

    def predict(self, horizon, record_dt=10.0, allow_switching=True, wind=None):
        """Forecast without changing this object.  Returns a Forecast with
        particle positions every record_dt seconds out to horizon.
        Intent switching stays on by default, so the forecast includes the
        chance that the target changes its plan."""
        sim = copy.deepcopy(self)
        n_rec = int(round(horizon / record_dt))
        t_rec = np.arange(1, n_rec + 1) * record_dt
        pos = np.empty((n_rec, self.N, 3))
        for k in range(n_rec):
            sim.propagate(record_dt, allow_switching=allow_switching, wind=wind)
            pos[k] = sim.positions()
        return Forecast(t_rec, pos, np.exp(sim.logw), sim.intent.copy(), self.names)


# ---------------------------------------------------------------------------
# Forecast container and summaries
# ---------------------------------------------------------------------------
class Forecast:
    """Particle forecast.  pos[k] = positions (N,3) at time t[k] ahead."""

    def __init__(self, t, pos, w, intent, names):
        self.t, self.pos, self.w, self.intent, self.names = t, pos, w / w.sum(), intent, names

    def index(self, t_ahead):
        return int(np.argmin(np.abs(self.t - t_ahead)))

    def mean(self, k):
        return self.w @ self.pos[k]

    def intent_probabilities(self):
        return np.array([self.w[self.intent == j].sum() for j in range(len(self.names))])

    def intent_summary(self, k, min_prob=1e-3):
        """Per-intent (name, probability, mean, covariance) at record k."""
        out = []
        for j, name in enumerate(self.names):
            m = self.intent == j
            pj = self.w[m].sum()
            if pj < min_prob or m.sum() < 5:
                continue
            wj = self.w[m] / pj
            mu = wj @ self.pos[k][m]
            d = self.pos[k][m] - mu
            out.append((name, pj, mu, (wj[:, None] * d).T @ d))
        return out

    def map_mean(self, k):
        """Mean position of the most probable intent (a 'best guess' point
        that, unlike the overall mean, lies on a flyable path)."""
        best = max(self.intent_summary(k), key=lambda s: s[1])
        return best[2]

    def _density(self, k, pts, max_pts=1500, rng=None):
        """Mixture of per-intent kernel density estimates (adapts to curved,
        multi-modal clouds better than one Gaussian)."""
        rng = rng or np.random.default_rng(0)
        dens = np.zeros(len(pts))
        for j in range(len(self.names)):
            m = np.flatnonzero(self.intent == j)
            pj = self.w[m].sum()
            if pj < 1e-3 or m.size < 20:
                continue
            if m.size > max_pts:
                m = rng.choice(m, max_pts, replace=False, p=self.w[m] / pj)
                wj = None
            else:
                wj = self.w[m] / pj
            data = self.pos[k][m].T
            data = data + 1e-3 * rng.standard_normal(data.shape)  # avoid singular cov
            dens += pj * gaussian_kde(data, weights=wj)(pts.T)
        return dens

    def hpd_contains(self, k, truth, level=0.95):
        """Is `truth` inside the highest-density region holding `level` of
        the probability?  (The multi-modal analogue of a 95% ellipsoid.)"""
        rng = np.random.default_rng(1)
        n_eval = min(2000, len(self.w))
        ev = rng.choice(len(self.w), n_eval, replace=True, p=self.w)
        d_part = self._density(k, self.pos[k][ev], rng=rng)
        threshold = np.quantile(d_part, 1.0 - level)
        return bool(self._density(k, np.atleast_2d(truth), rng=rng)[0] >= threshold)
