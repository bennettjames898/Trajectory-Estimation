import numpy as np
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.patches import Circle
from mpl_toolkits.mplot3d.art3d import Line3DCollection
from scipy.stats import gaussian_kde


class HistoryAwareDronePredictor:
    """
    Long-horizon drone trajectory predictor for automated flight paths.
    Uses historical kinematics to infer Bayesian goal weights, adaptive flight limits,
    and altitude-hold behavior, then rolls out 7th-order minimum-snap splines
    filtered by aerodynamic feasibility and obstacle avoidance.
    """

    def __init__(self, default_max_speed=20.0, default_max_accel=8.0, rationality_beta=0.05):
        self.default_max_speed = default_max_speed
        self.default_max_accel = default_max_accel
        self.beta = rationality_beta

    def analyze_history(self, history, timestamps, goals=None):
        """
        Extracts exact current state (including jerk), adaptive flight limits,
        altitude-hold status, and Bayesian goal weights from historical data.

        Parameters
        ----------
        history : np.ndarray, shape (K, 9)
            Columns: [x, y, z, vx, vy, vz, ax, ay, az]
        timestamps : np.ndarray, shape (K,)
            Monotonically increasing timestamps in seconds.
        goals : list of dict, optional
            Candidate goal dicts with keys 'pos', 'weight', 'spread'.
        """
        pos_hist = history[:, 0:3]
        vel_hist = history[:, 3:6]
        acc_hist = history[:, 6:9]

        p0 = pos_hist[-1]
        v0 = vel_hist[-1]
        a0 = acc_hist[-1]
        if len(timestamps) >= 2:
            dt = timestamps[-1] - timestamps[-2]
            j0 = (acc_hist[-1] - acc_hist[-2]) / max(dt, 1e-6)
        else:
            j0 = np.zeros(3)

        state_0 = {'p': p0, 'v': v0, 'a': a0, 'j': j0}

        speeds = np.linalg.norm(vel_hist, axis=1)
        accels = np.linalg.norm(acc_hist, axis=1)

        observed_cruise = np.percentile(speeds, 90)
        adaptive_max_speed = min(
            max(observed_cruise * 1.15, np.linalg.norm(v0) * 1.1, 3.0),
            self.default_max_speed
        )

        observed_max_accel = np.percentile(accels, 95)
        adaptive_max_accel = min(
            max(observed_max_accel * 1.2, np.linalg.norm(a0) * 1.1, 1.5),
            self.default_max_accel
        )

        z_std = np.std(pos_hist[:, 2])
        vz_std = np.std(vel_hist[:, 2])
        altitude_hold = (z_std < 0.5) and (vz_std < 0.25)

        inferred_goals = None
        if goals:
            inferred_goals = self._compute_bayesian_goal_weights(
                pos_hist, vel_hist, acc_hist, timestamps, adaptive_max_speed, goals
            )

        profile = {
            'max_speed': adaptive_max_speed,
            'max_accel': adaptive_max_accel,
            'cruise_speed': observed_cruise,
            'altitude_hold': altitude_hold
        }
        return state_0, profile, inferred_goals

    def _min_snap_cost(self, p_start, v_start, a_start, j_start, p_end, v_end, T):
        """
        Computes the exact analytical integrated squared snap over [0, T]
        for a 7th-order minimum-snap trajectory.
        """
        coeffs = self.solve_min_snap_batch(
            p_start[None, :], v_start[None, :], a_start[None, :], j_start[None, :],
            p_end[None, :], v_end[None, :], np.zeros((1, 3)), np.zeros((1, 3)), np.array([T])
        )[0]

        c4, c5, c6, c7 = coeffs[4], coeffs[5], coeffs[6], coeffs[7]
        t_powers = np.array([T, T**2, T**3, T**4, T**5, T**6, T**7])
        total_cost = 0.0
        for d in range(3):
            a, b, c, e = 24 * c4[d], 120 * c5[d], 360 * c6[d], 840 * c7[d]
            poly_sq = np.array([
                a**2,
                2 * a * b,
                b**2 + 2 * a * c,
                2 * a * e + 2 * b * c,
                c**2 + 2 * b * e,
                2 * c * e,
                e**2
            ])
            integrals = poly_sq / np.arange(1, 8)
            total_cost += np.dot(integrals, t_powers)
        return total_cost

    def _compute_bayesian_goal_weights(self, pos_hist, vel_hist, acc_hist, timestamps, cruise_speed, goals):
        """
        Scores each candidate goal via Maximum Entropy Inverse Optimal Control,
        comparing past + remaining minimum-snap cost against the direct optimal path.
        """
        p_start, v_start, a_start = pos_hist[0], vel_hist[0], acc_hist[0]
        p_now, v_now, a_now = pos_hist[-1], vel_hist[-1], acc_hist[-1]
        dt_start = max(timestamps[1] - timestamps[0], 1e-6)
        dt_now = max(timestamps[-1] - timestamps[-2], 1e-6)
        j_start = (acc_hist[1] - acc_hist[0]) / dt_start
        j_now = (acc_hist[-1] - acc_hist[-2]) / dt_now

        dt_avg = np.mean(np.diff(timestamps))
        jerk_hist = np.gradient(acc_hist, dt_avg, axis=0)
        snap_hist = np.gradient(jerk_hist, dt_avg, axis=0)
        cost_past = np.sum(np.linalg.norm(snap_hist, axis=1)**2) * dt_avg

        updated_goals = []
        raw_posteriors = []
        eff_speed = max(cruise_speed, 5.0)

        for g in goals:
            g_pos = np.array(g['pos'])
            prior = g.get('weight', 1.0 / len(goals))

            t_rem = max(np.linalg.norm(g_pos - p_now) / eff_speed, 1.0)
            t_total = max(np.linalg.norm(g_pos - p_start) / eff_speed, 1.5)

            cost_rem = self._min_snap_cost(p_now, v_now, a_now, j_now, g_pos, np.zeros(3), t_rem)
            cost_direct = self._min_snap_cost(p_start, v_start, a_start, j_start, g_pos, np.zeros(3), t_total)

            excess_cost = max(0.0, (cost_past + cost_rem) - cost_direct)
            likelihood = prior * np.exp(-self.beta * excess_cost)
            raw_posteriors.append(likelihood)

        raw_posteriors = np.array(raw_posteriors)
        norm_weights = raw_posteriors / np.sum(raw_posteriors)

        for g, w in zip(goals, norm_weights):
            new_g = g.copy()
            new_g['weight'] = float(w)
            updated_goals.append(new_g)

        return updated_goals

    def solve_min_snap_batch(self, p0, v0, a0, j0, pf, vf, af, jf, T):
        """
        Solves 7th-order minimum-snap polynomial coefficients in closed form
        for N trajectories simultaneously.
        """
        N = pf.shape[0]
        coeffs = np.zeros((N, 8, 3))

        coeffs[:, 0, :] = p0
        coeffs[:, 1, :] = v0
        coeffs[:, 2, :] = a0 / 2.0
        coeffs[:, 3, :] = j0 / 6.0

        T2, T3, T4, T5, T6, T7 = T**2, T**3, T**4, T**5, T**6, T**7

        b0 = pf - (p0 + v0 * T[:, None] + (a0 / 2.0) * T2[:, None] + (j0 / 6.0) * T3[:, None])
        b1 = vf - (v0 + a0 * T[:, None] + (j0 / 2.0) * T2[:, None])
        b2 = af - (a0 + j0 * T[:, None])
        b3 = jf - j0

        coeffs[:, 4, :] = (35 * b0 - 15 * b1 * T[:, None] + 2.5 * b2 * T2[:, None] - (1 / 6) * b3 * T3[:, None]) / T4[:, None]
        coeffs[:, 5, :] = (-84 * b0 + 39 * b1 * T[:, None] - 7.0 * b2 * T2[:, None] + 0.5 * b3 * T3[:, None]) / T5[:, None]
        coeffs[:, 6, :] = (70 * b0 - 34 * b1 * T[:, None] + 6.5 * b2 * T2[:, None] - 0.5 * b3 * T3[:, None]) / T6[:, None]
        coeffs[:, 7, :] = (-20 * b0 + 10 * b1 * T[:, None] - 2.0 * b2 * T2[:, None] + (1 / 6) * b3 * T3[:, None]) / T7[:, None]

        return coeffs

    def evaluate_trajectories(self, coeffs, t_eval):
        """
        Evaluates positions, velocities, and accelerations at timesteps t_eval (shape: (M,)).
        """
        powers = np.arange(8)
        t_pos = t_eval[:, None] ** powers[None, :]

        t_vel = np.zeros_like(t_pos)
        t_vel[:, 1:] = powers[1:] * (t_eval[:, None] ** powers[:-1])

        t_acc = np.zeros_like(t_pos)
        t_acc[:, 2:] = powers[2:] * powers[1:-1] * (t_eval[:, None] ** powers[:-2])

        pos = np.einsum('nkd,mk->nmd', coeffs, t_pos)
        vel = np.einsum('nkd,mk->nmd', coeffs, t_vel)
        acc = np.einsum('nkd,mk->nmd', coeffs, t_acc)
        return pos, vel, acc

    def predict_from_history(self, history, timestamps, horizon=5.0, n_samples=4000, goals=None, obstacles=None):
        """
        Generates the 3D future probability cloud and KDE model at t = horizon.
        """
        state_0, profile, inferred_goals = self.analyze_history(history, timestamps, goals)
        p0, v0, a0, j0 = state_0['p'], state_0['v'], state_0['a'], state_0['j']

        speed = np.linalg.norm(v0)
        heading = v0 / speed if speed > 0.1 else np.array([1.0, 0.0, 0.0])

        if inferred_goals:
            max_conf = max(g['weight'] for g in inferred_goals)
            goal_ratio = np.clip(0.5 + 0.4 * max_conf, 0.5, 0.85)
            n_goal_samples = int(n_samples * goal_ratio)
        else:
            n_goal_samples = 0
        n_explore_samples = n_samples - n_goal_samples

        waypoints = []
        if inferred_goals and n_goal_samples > 0:
            weights = np.array([g['weight'] for g in inferred_goals])
            chosen_goals = np.random.choice(len(inferred_goals), size=n_goal_samples, p=weights)
            for idx in chosen_goals:
                g = inferred_goals[idx]
                spread = np.array([g['spread'], g['spread'], 0.3 if profile['altitude_hold'] else g['spread'] * 0.5])
                pt = np.random.normal(loc=g['pos'], scale=spread)
                waypoints.append(pt)

        if n_explore_samples > 0:
            nominal_dist = max(profile['cruise_speed'], 5.0) * horizon
            cone_center = p0 + heading * nominal_dist
            z_spread = 0.4 if profile['altitude_hold'] else nominal_dist * 0.15
            spread = np.array([nominal_dist * 0.35, nominal_dist * 0.35, z_spread])
            explore_pts = np.random.normal(loc=cone_center, scale=spread, size=(n_explore_samples, 3))
            waypoints.extend(explore_pts)

        pf = np.array(waypoints)
        T = np.random.uniform(horizon * 0.85, horizon * 1.4, size=n_samples)
        vf = (pf - p0) / T[:, None] * 0.5
        af = np.zeros_like(pf)
        jf = np.zeros_like(pf)

        coeffs = self.solve_min_snap_batch(
            np.tile(p0, (n_samples, 1)), np.tile(v0, (n_samples, 1)),
            np.tile(a0, (n_samples, 1)), np.tile(j0, (n_samples, 1)),
            pf, vf, af, jf, T
        )

        t_steps = np.linspace(0, horizon, 50)
        pos, vel, acc = self.evaluate_trajectories(coeffs, t_steps)

        speeds = np.linalg.norm(vel, axis=2)
        accels = np.linalg.norm(acc, axis=2)
        valid_mask = (speeds.max(axis=1) <= profile['max_speed']) & (accels.max(axis=1) <= profile['max_accel'])

        if obstacles:
            for obs in obstacles:
                obs_pos = np.array(obs['pos'])
                dists = np.linalg.norm(pos - obs_pos[None, None, :], axis=2)
                valid_mask &= (dists.min(axis=1) > obs['radius'])

        valid_trajectories = pos[valid_mask]
        if len(valid_trajectories) < 10:
            raise ValueError("Too few valid trajectories survived constraints. Relax limits or increase n_samples.")

        valid_final_positions = valid_trajectories[:, -1, :]
        kde = gaussian_kde(valid_final_positions.T)
        densities = kde(valid_final_positions.T)

        return {
            'state_0': state_0,
            'profile': profile,
            'inferred_goals': inferred_goals,
            'trajectories': valid_trajectories,
            'cloud_points': valid_final_positions,
            'densities': densities,
            'kde_model': kde,
            'survival_rate': len(valid_final_positions) / n_samples
        }


def plot_prediction_3d(history, result, obstacles=None, max_lines=150):
    """
    Renders an interactive 3D Matplotlib view of the historical path, candidate
    minimum-snap splines, density-colored future cloud, goals, and obstacles.
    """
    plt.style.use('dark_background')
    fig = plt.figure(figsize=(12, 8))
    ax = fig.add_subplot(111, projection='3d')

    pos_hist = history[:, 0:3]
    ax.plot(pos_hist[:, 0], pos_hist[:, 1], pos_hist[:, 2], color='lime', linewidth=3.0, label='Observed History')

    trajs = result['trajectories']
    step = max(1, len(trajs) // max_lines)
    line_collection = Line3DCollection(trajs[::step], colors='deepskyblue', alpha=0.15, linewidths=1.0)
    ax.add_collection3d(line_collection)

    pts = result['cloud_points']
    scatter = ax.scatter(
        pts[:, 0], pts[:, 1], pts[:, 2],
        c=result['densities'], cmap='plasma', s=12, alpha=0.85, label='Future Position Cloud'
    )
    cbar = fig.colorbar(scatter, ax=ax, shrink=0.6, pad=0.08)
    cbar.set_label('3D Probability Density')

    p0 = result['state_0']['p']
    v0 = result['state_0']['v']
    ax.scatter(*p0, color='lime', s=90, marker='D', label='Current Position (t=0)', zorder=10)
    ax.quiver(p0[0], p0[1], p0[2], v0[0], v0[1], v0[2], length=1.0, color='lime', linewidth=2.5)

    inferred_goals = result['inferred_goals']
    if inferred_goals:
        for i, g in enumerate(inferred_goals):
            gx, gy, gz = g['pos']
            ax.scatter(gx, gy, gz, color='cyan', s=120, marker='X', label='Candidate Goals' if i == 0 else '')
            ax.text(gx, gy, gz - 3.5, f"Goal {i+1}\nInferred P={g['weight']*100:.1f}%", color='cyan', fontsize=9, ha='center')

    if obstacles:
        u = np.linspace(0, 2 * np.pi, 24)
        v = np.linspace(0, np.pi, 18)
        for i, obs in enumerate(obstacles):
            cx, cy, cz = obs['pos']
            r = obs['radius']
            sx = cx + r * np.outer(np.cos(u), np.sin(v))
            sy = cy + r * np.outer(np.sin(u), np.sin(v))
            sz = cz + r * np.outer(np.ones(np.size(u)), np.cos(v))
            ax.plot_surface(sx, sy, sz, color='crimson', alpha=0.45, linewidth=0)
            if i == 0:
                ax.plot([], [], [], color='crimson', marker='o', markersize=10, linestyle='None', alpha=0.6, label='Obstacle')

    all_x = np.concatenate([pts[:, 0], pos_hist[:, 0]])
    all_y = np.concatenate([pts[:, 1], pos_hist[:, 1]])
    all_z = np.concatenate([pts[:, 2], pos_hist[:, 2]])
    max_range = max(all_x.ptp(), all_y.ptp(), all_z.ptp()) / 2.0
    ax.set_xlim(all_x.mean() - max_range, all_x.mean() + max_range)
    ax.set_ylim(all_y.mean() - max_range, all_y.mean() + max_range)
    ax.set_zlim(all_z.mean() - max_range, all_z.mean() + max_range)

    prof = result['profile']
    ax.set_title(
        f"3D History-Refined Drone Prediction (Cruise: {prof['cruise_speed']:.1f} m/s | "
        f"Alt-Hold: {prof['altitude_hold']})", pad=15
    )
    ax.set_xlabel('X (meters)')
    ax.set_ylabel('Y (meters)')
    ax.set_zlabel('Altitude Z (meters)')
    ax.view_init(elev=30, azim=-130)
    ax.legend(loc='upper left', framealpha=0.6)
    plt.tight_layout()


def plot_prediction_2d(history, result, obstacles=None, max_lines=120, show_contours=True):
    """
    Produces a 3-panel 2D orthogonal projection figure:
      1. Top-Down View (X vs Y)
      2. Side Profile View (X vs Altitude Z)
      3. Front/Rear View (Y vs Altitude Z)
    Includes 2D KDE probability density contours, scatter cloud, splines, and obstacles.
    """
    plt.style.use('dark_background')
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    views = [
        {'ax': axes[0], 'dims': (0, 1), 'title': 'Top-Down View (X-Y Plane)', 'xlabel': 'X (m)', 'ylabel': 'Y (m)'},
        {'ax': axes[1], 'dims': (0, 2), 'title': 'Side Profile (X-Z Altitude)', 'xlabel': 'X (m)', 'ylabel': 'Altitude Z (m)'},
        {'ax': axes[2], 'dims': (1, 2), 'title': 'Front/Rear View (Y-Z Altitude)', 'xlabel': 'Y (m)', 'ylabel': 'Altitude Z (m)'}
    ]

    pos_hist = history[:, 0:3]
    trajs = result['trajectories']
    pts = result['cloud_points']
    densities = result['densities']
    p0 = result['state_0']['p']
    v0 = result['state_0']['v']
    inferred_goals = result['inferred_goals']

    step = max(1, len(trajs) // max_lines)
    traj_subset = trajs[::step]

    for v in views:
        ax = v['ax']
        d1, d2 = v['dims']

        if show_contours and np.std(pts[:, d1]) > 0.1 and np.std(pts[:, d2]) > 0.1:
            try:
                kde_2d = gaussian_kde(pts[:, [d1, d2]].T)
                pad1 = max(pts[:, d1].ptp() * 0.15, 5.0)
                pad2 = max(pts[:, d2].ptp() * 0.15, 5.0)
                grid_1 = np.linspace(pts[:, d1].min() - pad1, pts[:, d1].max() + pad1, 80)
                grid_2 = np.linspace(pts[:, d2].min() - pad2, pts[:, d2].max() + pad2, 80)
                G1, G2 = np.meshgrid(grid_1, grid_2)
                Z_density = kde_2d(np.vstack([G1.ravel(), G2.ravel()])).reshape(G1.shape)

                ax.contourf(G1, G2, Z_density, levels=12, cmap='magma', alpha=0.45)
                ax.contour(G1, G2, Z_density, levels=6, colors='white', linewidths=0.5, alpha=0.3)
            except np.linalg.LinAlgError:
                pass

        segments_2d = traj_subset[:, :, [d1, d2]]
        lc = LineCollection(segments_2d, colors='deepskyblue', alpha=0.15, linewidths=0.9)
        ax.add_collection(lc)

        sc = ax.scatter(
            pts[:, d1], pts[:, d2],
            c=densities, cmap='plasma', s=10, alpha=0.75, zorder=4, label='Probable Positions'
        )

        ax.plot(pos_hist[:, d1], pos_hist[:, d2], color='lime', linewidth=2.5, zorder=6, label='Observed History')
        ax.scatter(p0[d1], p0[d2], color='lime', s=70, marker='D', zorder=7, label='Current State (t=0)')
        ax.quiver(
            p0[d1], p0[d2], v0[d1], v0[d2],
            angles='xy', scale_units='xy', scale=1.0, color='lime', width=0.006, zorder=7
        )

        if inferred_goals:
            for i, g in enumerate(inferred_goals):
                gp = g['pos']
                ax.scatter(
                    gp[d1], gp[d2], color='cyan', s=100, marker='X', zorder=8,
                    label='Candidate Goals' if i == 0 else ''
                )
                ax.annotate(
                    f"G{i+1} ({g['weight']*100:.0f}%)",
                    (gp[d1], gp[d2]), textcoords='offset points', xytext=(0, -14),
                    ha='center', color='cyan', fontsize=8.5, fontweight='bold'
                )

        if obstacles:
            for i, obs in enumerate(obstacles):
                op = obs['pos']
                circle = Circle(
                    (op[d1], op[d2]), obs['radius'],
                    facecolor='crimson', edgecolor='red', alpha=0.45, linewidth=1.5, zorder=5,
                    label='Obstacle' if i == 0 else ''
                )
                ax.add_patch(circle)

        ax.set_title(v['title'], fontsize=11, pad=10)
        ax.set_xlabel(v['xlabel'])
        ax.set_ylabel(v['ylabel'])
        ax.grid(True, linestyle='--', alpha=0.2)
        ax.set_aspect('equal', adjustable='datalim')

    cbar = fig.colorbar(sc, ax=axes.ravel().tolist(), shrink=0.85, pad=0.02)
    cbar.set_label('3D Probability Density')

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='upper center', bbox_to_anchor=(0.5, 0.99), ncol=5, framealpha=0.7)
    plt.suptitle('2D Orthogonal Projections of Probable Future Drone Positions', fontsize=14, y=1.05)


if __name__ == '__main__':
    np.random.seed(42)

    # Simulate 3.0 seconds of past data (31 samples at 10 Hz)
    t_hist = np.linspace(-3.0, 0.0, 31)
    x_h = 10.0 * t_hist
    y_h = 0.45 * (t_hist + 3.0)**2 - 4.05
    z_h = np.full_like(t_hist, 50.0)

    vx_h = np.full_like(t_hist, 10.0)
    vy_h = 0.90 * (t_hist + 3.0)
    vz_h = np.zeros_like(t_hist)

    ax_h = np.zeros_like(t_hist)
    ay_h = np.full_like(t_hist, 0.90)
    az_h = np.zeros_like(t_hist)

    history_log = np.column_stack([x_h, y_h, z_h, vx_h, vy_h, vz_h, ax_h, ay_h, az_h])

    candidate_goals = [
        {'pos': [80.0, 35.0, 50.0], 'weight': 0.5, 'spread': 8.0},
        {'pos': [85.0, -30.0, 45.0], 'weight': 0.5, 'spread': 10.0}
    ]

    known_obstacles = [
        {'pos': [40.0, 5.0, 50.0], 'radius': 11.0}
    ]

    predictor = HistoryAwareDronePredictor(rationality_beta=0.04)
    result = predictor.predict_from_history(
        history=history_log,
        timestamps=t_hist,
        horizon=5.5,
        n_samples=4000,
        goals=candidate_goals,
        obstacles=known_obstacles
    )

    print(f"Valid trajectories survived: {result['survival_rate']*100:.1f}%")
    for i, g in enumerate(result['inferred_goals']):
        print(f"Goal {i+1} Posterior Probability: {g['weight']*100:.1f}%")

    plot_prediction_3d(history_log, result, obstacles=known_obstacles)
    plot_prediction_2d(history_log, result, obstacles=known_obstacles)
    plt.show()
