# Automated Drone Trajectory Prediction: Architecture & Mathematical Guide

## 1. Overview
This document summarizes the mathematical formulation and software architecture for predicting the future 3D position cloud of an automated drone over long time horizons ($T > 3\text{ seconds}$) using noiseless sensor measurements and historical kinematic logs.

Unlike noisy radar tracking—which relies on stochastic state estimation (such as an IMM-UKF) to filter out measurement errors—a theoretical perfect sensor provides exact instantaneous position, velocity, and acceleration. Consequently, the core challenge shifts from **state estimation** to **behavioral intent inference** and **optimal trajectory sampling**.

---

## 2. System Architecture Pipeline

1. **Historical Profiling (`analyze_history`)**
   * Extracts exact current state $\mathbf{x}_0 = [\mathbf{p}_0, \mathbf{v}_0, \mathbf{a}_0, \mathbf{j}_0]$, computing current jerk via finite differences: $\mathbf{j}_0 = \frac{\mathbf{a}_k - \mathbf{a}_{k-1}}{\Delta t}$.
   * Profiles the onboard autopilot's flight envelope using 90th/95th percentiles of observed cruise speeds and accelerations.
   * Detects **Altitude-Hold Mode** by evaluating vertical position ($\sigma_z$) and velocity ($\sigma_{v_z}$) variance.

2. **Bayesian Intent Inference (`_compute_bayesian_goal_weights`)**
   * Evaluates candidate goals using **Maximum Entropy Inverse Optimal Control (IOC)**.
   * Compares the minimum-snap control effort required to reach each goal via the observed path against the direct optimal path from the start of the history window.

3. **Minimum-Snap Monte Carlo Rollouts (`solve_min_snap_batch`)**
   * Samples $N$ candidate target waypoints biased toward high-probability goals and a forward cruise cone.
   * Solves closed-form **7th-order minimum-snap polynomials** locked to the exact initial boundary conditions $[\mathbf{p}_0, \mathbf{v}_0, \mathbf{a}_0, \mathbf{j}_0]$.

4. **Feasibility Filtering & Density Estimation (`predict_from_history`)**
   * Prunes trajectories that violate inferred aerodynamic limits ($v_{\max}, a_{\max}$) or intersect 3D spherical obstacles.
   * Fits a **Gaussian Kernel Density Estimate (KDE)** over the surviving terminal positions to represent multi-modal probability clouds.

---

## 3. Core Mathematical Formulations

### 3.1 7th-Order Minimum-Snap Trajectory Spline
Automated flight controllers (e.g., PX4, ArduPilot) generate smooth trajectories by minimizing **snap** (the 4th derivative of position) to reduce motor torque spikes and stabilize sensors. For each spatial axis $d \in \{x, y, z\}$, a trajectory over horizon $T$ is parameterized as:

$$p(t) = \sum_{k=0}^{7} c_k t^k$$

* **Initial Boundary Conditions (Locked at $t = 0$):**
  $$c_0 = p_0, \quad c_1 = v_0, \quad c_2 = \frac{a_0}{2}, \quad c_3 = \frac{j_0}{6}$$

* **Terminal Boundary Conditions (Solved at $t = T$):**
  Given target waypoint state $[p_f, v_f, a_f, j_f]$, define the residual vector $\mathbf{b} = [b_0, b_1, b_2, b_3]^T$:
  $$b_0 = p_f - \left(p_0 + v_0 T + \frac{1}{2}a_0 T^2 + \frac{1}{6}j_0 T^3\right)$$
  $$b_1 = v_f - \left(v_0 + a_0 T + \frac{1}{2}j_0 T^2\right)$$
  $$b_2 = a_f - \left(a_0 + j_0 T\right)$$
  $$b_3 = j_f - j_0$$

  The remaining coefficients $[c_4, c_5, c_6, c_7]$ are computed analytically in closed form:
  $$c_4 = \frac{35 b_0 - 15 b_1 T + 2.5 b_2 T^2 - \frac{1}{6} b_3 T^3}{T^4}$$
  $$c_5 = \frac{-84 b_0 + 39 b_1 T - 7.0 b_2 T^2 + 0.5 b_3 T^3}{T^5}$$
  $$c_6 = \frac{70 b_0 - 34 b_1 T + 6.5 b_2 T^2 - 0.5 b_3 T^3}{T^6}$$
  $$c_7 = \frac{-20 b_0 + 10 b_1 T - 2.0 b_2 T^2 + \frac{1}{6} b_3 T^3}{T^7}$$

### 3.2 Control Cost & Bayesian Goal Weighting
The total control effort $C$ of a trajectory is defined as the integrated squared snap over $[0, T]$:

$$C = \int_{0}^{T} \left\| \frac{d^4 \mathbf{p}(t)}{dt^4} \right\|^2 dt$$

For each candidate goal $G_i$ with prior probability $P(G_i)$, the posterior weight $w_i$ is updated via Maximum Entropy IOC:

$$w_i \propto P(G_i) \exp\Big(-\beta \big[ C_{\text{past}}(\mathbf{p}_{\text{start}} \to \mathbf{p}_0) + C^*(\mathbf{p}_0 \to G_i) - C^*(\mathbf{p}_{\text{start}} \to G_i) \big]\Big)$$

where $\beta > 0$ is the rationality parameter governing how sharply suboptimal detours are penalized.

---

## 4. Input & Output Data Specification

| Parameter | Shape / Type | Description |
| :--- | :--- | :--- |
| `history` | `(K, 9)` `ndarray` | Time-ordered log of `[x, y, z, vx, vy, vz, ax, ay, az]` in meters and seconds. |
| `timestamps` | `(K,)` `ndarray` | Monotonically increasing timestamps corresponding to each row in `history`. |
| `horizon` | `float` | Prediction lookahead time $\Delta t$ in seconds. |
| `goals` | `list[dict]` | Candidate targets formatted as `{'pos': [x, y, z], 'weight': float, 'spread': float}`. |
| `obstacles` | `list[dict]` | Spherical no-fly zones formatted as `{'pos': [x, y, z], 'radius': float}`. |
| `cloud_points` | `(M, 3)` `ndarray` | Surviving future 3D coordinates at $t = t_0 + \text{horizon}$. |
| `kde_model` | `gaussian_kde` | Continuous 3D probability density function callable on arbitrary `(3, Q)` query points. |

---

## 5. Visualization Outputs
* **3D Perspective (`plot_prediction_3d`)**: Displays the observed historical trajectory, sampled minimum-snap splines, KDE-colored terminal cloud, Bayesian posterior goal probabilities, and 3D spherical obstacle surfaces on equal-aspect axes.
* **2D Orthogonal Projections (`plot_prediction_2d`)**: Renders **Top-Down (X-Y)**, **Side Profile (X-Z)**, and **Front/Rear (Y-Z)** views overlaid with 2D KDE probability density contours (`magma`) and circular obstacle cross-sections.
